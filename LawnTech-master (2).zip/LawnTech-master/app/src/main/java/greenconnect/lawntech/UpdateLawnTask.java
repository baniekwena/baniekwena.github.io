package greenconnect.lawntech;

import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class UpdateLawnTask extends AsyncTask<Void, Void, Void> {

    SharedPreferences sharedPref;
    SharedPreferences.Editor editor;
    private static final String TAG = "UpdateLawnTask";
    private String wsURL = "";
    private UpdateLawnCallback callback;
    private String result;
    private String key = "";
    private double longitude = 0;
    private double latitude = 0;
    private double acres = 0;
    private String address = "";
    private String lawnname = "";
    private String pw_hash = "";
    private String appCode = "";

    private RestFetcher rest = null;

    public UpdateLawnTask(String ws, String l, double pw, double lon, String name, String adress, UpdateLawnCallback cb, RestFetcher r) {
        wsURL = ws;
        callback = cb;
        key = l;
        lawnname = name;
        longitude = lon;
        latitude = pw;
        address = adress;
        rest = r;
    }

    protected Void doInBackground(Void... params) {
        try {
            JSONArray req = new JSONArray();
            JSONObject obj = new JSONObject();
            // obj.put("action", "login");
            // req.put(obj);
            // obj = new JSONObject();
            //obj.put("login", login);
            // req.put(obj);
            //obj = new JSONObject();
            obj.put("location_id", 1);
            obj.put("latitude", latitude);
            obj.put("longitude", longitude);
            obj.put("acres", acres);
            obj.put("lawn_name", lawnname);
            obj.put("address", address);
            //req.put(obj);
            // obj = new JSONObject();
            //obj.put("session_type", "session_key");
            //req.put(obj);

            if(rest == null)
                System.out.println("rest is null");

            this.result = rest.getUrl(wsURL + key+"&json="+ obj.toString());
            System.out.println(wsURL + key+"&json="+ obj.toString());
            //System.out.println("HEllo");
            publishProgress();
        } catch (Exception e) {
            Log.e(TAG, "Failed to fetch URL: ", e);
            // System.out.println(req.toString());
        }
        return null;
    }

    //onProgressUpdate runs on the UI thread
    @Override
    protected void onProgressUpdate(Void... values) {
        try {
            JSONObject arr = new JSONObject(result);
            callback.onUpdateLawnTaskCompleted(arr);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
}

