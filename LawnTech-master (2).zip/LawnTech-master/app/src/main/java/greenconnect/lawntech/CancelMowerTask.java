package greenconnect.lawntech;

import android.os.AsyncTask;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class CancelMowerTask extends AsyncTask<Void, Void, Void> {
    private static final String TAG = "CancelMowerTask";
    private String wsURL = "";
    private CancelMowerCallback callback;
    private String result;
    private String transid = "";
    private String key = "";
    private String email = "";
    private String address = "";

    private double longitude = 0;
    private double latitude = 0;
    private double acres = 0;

    private RestFetcher rest = null;

    public CancelMowerTask(String ws,String Session, String l,  CancelMowerCallback cb, RestFetcher r) {
        wsURL = ws;
        callback = cb;
        transid = l;
        key = Session;
        rest = r;
    }

    protected Void doInBackground(Void... params) {
        try {
            JSONArray req = new JSONArray();
            JSONObject obj = new JSONObject();
            // obj.put("action", "login");
            // obj.put("action", "login");
            // req.put(obj);
            // obj = new JSONObject();
            //obj.put("login", login);
            // req.put(obj);
            //obj = new JSONObject();
            //obj.put("location_id", 1);
            obj.put("transaction_id", transid);
            obj.put("cancel_reason", "reason not specified");
           // obj.put("longitude", longitude);
            //obj.put("acres", acres);
           // obj.put("address", address);
            //req.put(obj);
            // obj = new JSONObject();
            //obj.put("session_type", "session_key");
            //req.put(obj);
            // req.put(obj);
            // obj = new JSONObject();

            // req.put(obj);
            //obj = new JSONObject();
            //obj.put("email", email);
            //req.put(obj);
            // obj = new JSONObject();
            //req.put(obj);

            if(rest == null)
                System.out.println("rest is null");

            this.result = rest.getUrl(wsURL + key+"&json="+ obj.toString());
            System.out.println(wsURL + key+"&json="+ obj.toString());
            //  System.out.println(wsURL + obj.toString());
            //System.out.println("HEllo");
            publishProgress();
        } catch (Exception e) {
            Log.e(TAG, "Failed to fetch URL: ", e);
            // System.out.println(req.toString());
        }
        return null;
    }

    //onProgressUpdate runs on the UI thread
    @Override
    protected void onProgressUpdate(Void... values) {
        try {
            JSONObject arr = new JSONObject(result);
            callback.onCancelMowerTaskCompleted(arr);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
}

