package greenconnect.lawntech;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.maps.model.LatLng;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

public class AddLawnActivity extends AppCompatActivity implements UpdateLawnCallback {


    SharedPreferences sharedPref;
    SharedPreferences.Editor editor;

    public static final String TAG = "AddLawnActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_lawn);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);


        TextView myTextView = (TextView) findViewById(R.id.toolbar_title);
        TextView Title = (TextView) findViewById(R.id.textView);
        Typeface typeface = Typeface.createFromAsset(getAssets(), "fonts/Aladin-Regular.ttf");
        myTextView.setTypeface(typeface);
        Title.setTypeface(typeface);


        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowTitleEnabled(false);


        final EditText LawnAddress = (EditText) findViewById(R.id.lawn_address);
        final EditText Lawnname = (EditText) findViewById(R.id.lawn_name);
        final EditText Acre = (EditText) findViewById(R.id.Acres);
        final Button bRegister = (Button) findViewById(R.id.submitButton);
        sharedPref = getSharedPreferences("session", Context.MODE_PRIVATE);
        final String Session = sharedPref.getString("key","");


        final String LawnAddres = LawnAddress.getText().toString();

        final String acres2 = Acre.getText().toString();


        MyApplication app = new MyApplication();

        //init the REST WS query object
        RestFetcher rest = new RestFetcher();
        try {
            InputStream caInput = this.getAssets().open("fulgentcorp.crt");
            rest.initKeyStore(caInput);
            caInput.close();
        } catch (IOException e) {
            Log.e(TAG, "*** initKeyStore error: " + e.getMessage());
        }
        app.setRest(rest);


        bRegister.setOnClickListener(new View.OnClickListener() {


            @Override
            public void onClick(View v) {

               // double acres = Double.parseDouble(acres2);
                double longitude = Longitude(AddLawnActivity.this, LawnAddress.getText().toString());
                double latitude = Latitude(AddLawnActivity.this, LawnAddress.getText().toString());

                editor = sharedPref.edit();
                editor.putString("address", LawnAddress.getText().toString());
                editor.commit();

                MyApplication app = new MyApplication();
                app.initSession();

                RestFetcher rest2 = new RestFetcher();
                try {
                    InputStream caInput = AddLawnActivity.this.getAssets().open("fulgentcorp.crt");
                    rest2.initKeyStore(caInput);
                    caInput.close();
                } catch (IOException e) {
                    Log.e(TAG, "*** initKeyStore error: " + e.getMessage());
                }


                new UpdateLawnTask(app.getNL_URL(),Session, latitude, longitude,Lawnname.getText().toString(),LawnAddress.getText().toString(), AddLawnActivity.this, rest2).execute();
            }


        });
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

    @Override
    public void onUpdateLawnTaskCompleted(JSONObject response) {
        try {
            boolean success = false;
            //iterate through the result and look for "success" result and the "session_key"

            if (response.has("result")) {
                if (response.get("result").equals("ok")) {

                    success = true;
                    //String username = response.getString("username");
                    Intent intent = new Intent(AddLawnActivity.this, MainMap.class);


                    Toast.makeText(this, "Lawn Added Successfully", Toast.LENGTH_SHORT).show();
                    //Intent intent =  new Intent(LoginActivity.this, MainMap.class);
                    this.startActivity(intent);
                    // Toast.makeText(this, "Login Passed. Please check your credentials", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, "Lawn Add Failed", Toast.LENGTH_SHORT).show();
                }
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }

    }



    public double Latitude(Context context, String strAddress) {

        Geocoder coder = new Geocoder(context);
        List<Address> address;
        LatLng p1 = null;
        double latitude = 0;

        try {
            // May throw an IOException
            address = coder.getFromLocationName(strAddress, 5);
            if (address == null) {
                return 0;
            }
            Address location = address.get(0);
            location.getLatitude();
            location.getLongitude();

            latitude = location.getLatitude();
            String longitude = Double.toString(location.getLongitude());

            // System.out.println(latitude);


            p1 = new LatLng(location.getLatitude(), location.getLongitude() );

        } catch (IOException ex) {

            ex.printStackTrace();
        }

        return latitude;
    }

    public double Longitude(Context context, String strAddress) {

        Geocoder coder = new Geocoder(context);
        List<Address> address;
        LatLng p1 = null;
        double longitude=0;

        try {
            // May throw an IOException
            address = coder.getFromLocationName(strAddress, 5);
            if (address == null) {
                return 0;
            }
            Address location = address.get(0);
            location.getLatitude();
            location.getLongitude();

            String latitude = Double.toString(location.getLatitude());
            longitude = location.getLongitude();


            p1 = new LatLng(location.getLatitude(), location.getLongitude() );

        } catch (IOException ex) {

            ex.printStackTrace();
        }

        return longitude;
    }
}
