package greenconnect.lawntech;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.widget.EditText;
import android.widget.TextView;



public class EditProfileActivity extends AppCompatActivity {

    private TextView txtname;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_profile);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        txtname = (TextView) findViewById(R.id.profileAddress);

        TextView myTextView = (TextView) findViewById(R.id.toolbar_title);
        Typeface typeface = Typeface.createFromAsset(getAssets(), "fonts/Aladin-Regular.ttf");
        myTextView.setTypeface(typeface);

        //String address = DataHolder.getInstance().getData();

        Intent intent = getIntent();
        String address = intent.getStringExtra("address");

       // SharedPreferences myprefs= getSharedPreferences("user", MODE_WORLD_READABLE);
       // String session_id = myprefs.getString("session_id", null);

       txtname.setText("address "+ address +"!");

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowTitleEnabled(false);

    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
}