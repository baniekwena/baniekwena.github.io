package greenconnect.lawntech;

import android.content.Context;
import android.content.Intent;
import android.graphics.Typeface;
import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.TextView;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import java.io.IOException;
import java.util.List;

public class ViewMyLawns extends AppCompatActivity implements OnMapReadyCallback {

    private GoogleMap mMap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_my_lawns);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent AddLawn = new Intent(ViewMyLawns.this, AddLawnActivity.class);
                ViewMyLawns.this.startActivity(AddLawn);
            }
        });

        TextView myTextView = (TextView) findViewById(R.id.toolbar_title);
        Typeface typeface = Typeface.createFromAsset(getAssets(), "fonts/Aladin-Regular.ttf");
        myTextView.setTypeface(typeface);

       getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowTitleEnabled(false);

    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        Intent intent2 = getIntent();
        //String Adress = "1600 Pennsylvania Ave NW, Washington, DC 20500";
        String address = intent2.getStringExtra("address");
        if(address.isEmpty()){address = "the White House";}
        String address2 = "UTSA blvd San Antonio Texas";
        String address3 = "310 S Frio St, San Antonio, Texas";

        // Add a marker in Sydney and move the camera
        LatLng CurrentLawn = getLocationFromAddress(this,address);
        mMap.addMarker(new MarkerOptions().position(CurrentLawn).title("The Main").snippet("Mower Rating: 5 Stars"));
        LatLng CurrentLawn2 = getLocationFromAddress(this,address2);
        mMap.addMarker(new MarkerOptions().position(CurrentLawn2).title("My School Lot").snippet("Mower Rating: 2 Stars"));
        LatLng CurrentLawn3 = getLocationFromAddress(this,address3);
        mMap.addMarker(new MarkerOptions().position(CurrentLawn3).title("BIG BOY").snippet("Mower Rating: 1 Star"));
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(CurrentLawn, 10));

    }

    public LatLng getLocationFromAddress(Context context, String strAddress) {

        Geocoder coder = new Geocoder(context);
        List<Address> address;
        LatLng p1 = null;

        try {
            // May throw an IOException
            address = coder.getFromLocationName(strAddress, 5);
            if (address == null) {
                return null;
            }
            Address location = address.get(0);
            location.getLatitude();
            location.getLongitude();

            p1 = new LatLng(location.getLatitude(), location.getLongitude() );

        } catch (IOException ex) {

            ex.printStackTrace();
        }

        return p1;
    }
}
