package greenconnect.lawntech;

        import android.app.Application;
        import android.content.res.Configuration;

public class MyApplication extends Application {
    private static final String WS_URL = "http://easel2.fulgentcorp.com:8081/login?service_key=lawntech&json=";
    public static final String WS_POST_URL = "https://easel1.fulgentcorp.com/bifrost/ws.php";
    private static final String WR_URL = "http://easel2.fulgentcorp.com:8081/addUser?service_key=lawntech&json=";
    private static final String UL_URL = "http://easel2.fulgentcorp.com:8081/getLocations?session_token=";
    private static final String NL_URL = "http://easel2.fulgentcorp.com:8081/updateLocation?session_token=";
    private static final String ML_URL = "http://easel2.fulgentcorp.com:8081/getMowers?session_token=";
    private static final String RM_URL = "http://easel2.fulgentcorp.com:8081/requestMow?session_token=";
    private static final String CM_URL = "http://easel2.fulgentcorp.com:8081/cancelMow?session_token=";

    private static MyApplication singleton;
    private String sessionKey;
    private RestFetcher rest;

    public MyApplication getInstance() {
        return singleton;
    }

    public String getWSURL() {
        return WS_URL;
    }

    public String getCMURL() {
        return CM_URL;
    }

    public String getWRURL(){ return WR_URL; }

    public String getULURL(){ return UL_URL; }

    public String getNL_URL(){return NL_URL;}

    public String getRM_URL(){return RM_URL;}

    public String getML_URL(){return ML_URL;}

    public String getWSPostURL() {
        return WS_POST_URL;
    }

    public RestFetcher getRest() {
        return rest;
    }

    public void setRest(RestFetcher rest) {
        this.rest = rest;
    }

    public void initSession() {
        //set session info to invalid values
        sessionKey = "";
    }

    public boolean isSessionValid() {
        if(sessionKey.length() > 0)
            return true;
        return false;
    }

    public String getSessionKey() {
        return sessionKey;
    }

    public void setSessionKey(String s) {
        this.sessionKey = s;
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
    }

    @Override
    public void onCreate() {
        super.onCreate();
        singleton = this;
        initSession();
    }

    @Override
    public void onLowMemory() {
        super.onLowMemory();
    }

    @Override
    public void onTerminate() {
        super.onTerminate();
    }

}
