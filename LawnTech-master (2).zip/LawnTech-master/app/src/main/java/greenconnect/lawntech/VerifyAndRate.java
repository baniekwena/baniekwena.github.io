package greenconnect.lawntech;

import android.content.Intent;
import android.graphics.Typeface;
import android.support.design.widget.NavigationView;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;



    public class VerifyAndRate extends AppCompatActivity {


    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_verify_and_rate);

        TextView Payment_Message = (TextView) findViewById(R.id.PC);
        TextView Rate = (TextView)findViewById(R.id.Rate2);


        TextView MowMessage = (TextView) findViewById(R.id.textView);
        Button Submit = (Button) findViewById(R.id.button2);

        Typeface typeface = Typeface.createFromAsset(getAssets(), "fonts/Aladin-Regular.ttf");
       // Submit.setTypeface(typeface);
       // Rate.setTypeface(typeface);
       // MowMessage.setTypeface(typeface);
      //  Payment_Message.setTypeface(typeface);
        Intent intent = getIntent();
        final String name = intent.getStringExtra("Mowername");
        final String payment = intent.getStringExtra("Payment");

        MowMessage.setText(name + " says your lawn has been mowed!");
        Rate.setText("Rate "+name+":");
        Payment_Message.setText(payment);

        Submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent registerIntent = new Intent(VerifyAndRate.this, MainMap.class);
                Toast.makeText(VerifyAndRate.this, "Thanks, "+name+" Mower has been sent rating!", Toast.LENGTH_SHORT).show();
                VerifyAndRate.this.startActivity(registerIntent);
            }
        });




    }

}









