package greenconnect.lawntech;

import android.os.AsyncTask;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class GetLocationTask extends AsyncTask<Void, Void, Void> {
    private static final String TAG = "LoginTask";
    private String wsURL = "";
    private GetLocationCallback callback;
    private String result;
    private String login = "";
    private String password = "";
    private String pw_hash = "";
    private String appCode = "";

    private RestFetcher rest = null;

    public GetLocationTask(String ws, String l, GetLocationCallback cb, RestFetcher r) {
        wsURL = ws;
        callback = cb;
        login = l;
        rest = r;
    }

    protected Void doInBackground(Void... params) {
        try {

            if(rest == null)
                System.out.println("rest is null");

           this.result = rest.getUrl(wsURL + login);
         System.out.println(wsURL + login);
           System.out.println(wsURL + login);
          publishProgress();
        } catch (Exception e) {
            Log.e(TAG, "Failed to fetch URL: ", e);
           // System.out.println(req.toString());
        }
        return null;
    }

    //onProgressUpdate runs on the UI thread
    @Override
    protected void onProgressUpdate(Void... values) {
        try {
            //JSONObject arr = new JSONObject(result);
            JSONObject arr = new JSONObject(result);
            callback.onGetLocationTaskCompleted(arr);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
}

