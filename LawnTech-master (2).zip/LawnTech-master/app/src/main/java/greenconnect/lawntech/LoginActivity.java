package greenconnect.lawntech;


import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.net.ConnectivityManager;
import android.net.Network;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

public class LoginActivity extends AppCompatActivity implements LoginCallback, GetLocationCallback {
    public static final String TAG = "LoginActivity";
    SharedPreferences sharedPref;
    SharedPreferences.Editor editor;
    private Button loginButton;
    private TextView tvLogin, tvPassword, tvAppCode;
    private EditText textSessionKey;
    private ArrayList<String> mlocate = new ArrayList();

    ProgressDialog progressDialog;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        Typeface typeface = Typeface.createFromAsset(getAssets(), "fonts/Aladin-Regular.ttf");

        final EditText etUsername = (EditText) findViewById(R.id.username);
        final EditText etPassword = (EditText) findViewById(R.id.password);
        final Button tvRegisterLink = (Button) findViewById(R.id.RegisterButton);
        final Button tvForgotLink = (Button) findViewById(R.id.ForgotButton);
        final Button bLogin = (Button) findViewById(R.id.LoginButton);

       // bLogin.setTypeface(typeface);
       // tvForgotLink.setTypeface(typeface);
       // tvRegisterLink.setTypeface(typeface);

        MyApplication app = new MyApplication();

        //init the REST WS query object
        RestFetcher rest = new RestFetcher();
        try {
            InputStream caInput = this.getAssets().open("fulgentcorp.crt");
            rest.initKeyStore(caInput);
            caInput.close();
        } catch (IOException e) {
            Log.e(TAG, "*** initKeyStore error: " + e.getMessage());
        }
        app.setRest(rest);


        tvRegisterLink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent registerIntent = new Intent(LoginActivity.this, UserRegistrationActivity.class);
                LoginActivity.this.startActivity(registerIntent);
            }
        });

        tvForgotLink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent forgotIntent = new Intent(LoginActivity.this, ForgotActivity.class);
                LoginActivity.this.startActivity(forgotIntent);
            }
        });
//insert begin
         final ConnectionDetector cd;
        cd = new ConnectionDetector(this);
        //insert end
        bLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MyApplication app = new MyApplication();
                app.initSession();


                    if(!cd.isConnected()){
                        Toast.makeText(LoginActivity.this,"No Network Connection",Toast.LENGTH_SHORT).show();

                    }

                RestFetcher rest2 = new RestFetcher();
                try {
                    InputStream caInput = LoginActivity.this.getAssets().open("fulgentcorp.crt");
                    rest2.initKeyStore(caInput);
                    caInput.close();
                } catch (IOException e) {
                    Log.e(TAG, "*** initKeyStore error: " + e.getMessage());
                }

                new LoginTask(app.getWSURL(), etUsername.getText().toString(), etPassword.getText().toString(), LoginActivity.this, rest2).execute();
            }
        });
    }


    @Override
    public void onLoginTaskCompleted(JSONObject response) {


        try {
            boolean success = false;
            //iterate through the result and look for "success" result and the "session_key"

            if (response.has("result")) {
                if (response.get("result").equals("ok")) {
                    String session_token = response.getString("session_token");

                    MyApplication app = new MyApplication();
                    app.initSession();

                    RestFetcher rest2 = new RestFetcher();
                    try {
                        InputStream caInput = LoginActivity.this.getAssets().open("fulgentcorp.crt");
                        rest2.initKeyStore(caInput);
                        caInput.close();
                    } catch (IOException e) {
                        Log.e(TAG, "*** initKeyStore error: " + e.getMessage());
                    }

                    sharedPref = getSharedPreferences("session", Context.MODE_PRIVATE);
                    editor = sharedPref.edit();
                    editor.putString("key", session_token);
                    editor.commit();

                    new GetLocationTask(app.getULURL(), session_token, LoginActivity.this, rest2).execute();


                    success = true;
                    // JSONObject obj = response.getJSONObject("address");
                    String price = "$50";
                    editor = sharedPref.edit();
                    editor.putString("price", price);
                    editor.commit();


                    //String username = response.getString("username");
                    Intent intent = new Intent(LoginActivity.this, MainMap.class);

                    intent.putExtra("price", price);
                    //intent.putExtra("username", username);

                    //Intent intent =  new Intent(LoginActivity.this, MainMap.class);
                    this.startActivity(intent);
                    // Toast.makeText(this, "Login Passed. Please check your credentials", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, "Login failed. Please check your credentials", Toast.LENGTH_SHORT).show();
                }
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onGetLocationTaskCompleted(JSONObject response) {
        String Session = sharedPref.getString("key","");

        try {
            JSONArray rows = response.getJSONArray("rows");
            if(rows.length()<2){
                //String session_token = intent.getStringExtra("session_token");
                System.out.println("Ur new!!!: "+Session);

                MyApplication app = new MyApplication();
                app.initSession();

                RestFetcher rest2 = new RestFetcher();
                try {
                    InputStream caInput = LoginActivity.this.getAssets().open("fulgentcorp.crt");
                    rest2.initKeyStore(caInput);
                    caInput.close();
                } catch (IOException e) {
                    Log.e(TAG, "*** initKeyStore error: " + e.getMessage());
                }
                new AddLawnTask(app.getNL_URL(),Session, rest2).execute();
                Intent intent = new Intent(LoginActivity.this, NewUserActivity.class)
                .setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                finish();
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(intent);
            }
            else {

                //for (int i = 0; i < rows.length(); i++) {
                JSONObject o = rows.getJSONObject(1);
                String latitude = o.getString("latitude");
                String longitude = o.getString("longitude");
                JSONObject n = o.getJSONObject("location_fields");
                String address = n.getString("address");
               // n.remove("address");
                String name = n.getString("name");
                editor = sharedPref.edit();
                editor.putString("name", name);
                editor.commit();
                editor = sharedPref.edit();
                editor.putString("latitude", latitude);
                editor.commit();
                editor = sharedPref.edit();
                editor.putString("longitude", longitude);
                editor.commit();
              editor = sharedPref.edit();
               editor.putString("address", address);
               editor.commit();

                System.out.println(name);
            }


               // JSONObject n = o.getJSONObject("location_fields");
              //  String name = n.getString("name");
               // System.out.println(name+"\n");
            //}


        } catch (JSONException e) {
            e.printStackTrace();
        }


    }
}

