package greenconnect.lawntech;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

/**
 * Created by Nanette on 6/21/2017.
 */

public class Profile extends AppCompatActivity{
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        final Button Update = (Button) findViewById(R.id.BUpdate);

        Update.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent RequestIntent = new Intent(Profile.this, CreditCardPaymentActivity.class);
                Profile.this.startActivity(RequestIntent);
            }
        });
    }
}



