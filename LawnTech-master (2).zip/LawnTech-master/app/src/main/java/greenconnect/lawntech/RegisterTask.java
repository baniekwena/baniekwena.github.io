package greenconnect.lawntech;

import android.os.AsyncTask;
import android.os.SystemClock;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class RegisterTask extends AsyncTask<Void, Void, Void> {
    private static final String TAG = "RegisterTask";
    private String wsURL = "";
    private RegisterCallback callback;
    private String result;
    private String login = "";
    private String password = "";
    private String pw_hash = "";
    private String appCode = "";

    private RestFetcher rest = null;

    public RegisterTask(String ws, String l, String pw, RegisterCallback cb, RestFetcher r) {
        wsURL = ws;
        callback = cb;
        login = l;
        pw_hash = pw;
        rest = r;
    }

    protected Void doInBackground(Void... params) {
        try {
            JSONArray req = new JSONArray();
            JSONObject obj = new JSONObject();
            // obj.put("action", "login");
            // req.put(obj);
            // obj = new JSONObject();
            obj.put("login", login);
            // req.put(obj);
            //obj = new JSONObject();
            obj.put("pw_hash", pw_hash);
            //req.put(obj);
            // obj = new JSONObject();
            obj.put("session_type", "session_key");
            //req.put(obj);

            if(rest == null)
                System.out.println("rest is null");

            this.result = rest.getUrl(wsURL + obj.toString());
            //  System.out.println(wsURL + obj.toString());
            //System.out.println("HEllo");
            publishProgress();
        } catch (Exception e) {
            Log.e(TAG, "Failed to fetch URL: ", e);
            // System.out.println(req.toString());
        }
        return null;
    }

    //onProgressUpdate runs on the UI thread
    @Override
    protected void onProgressUpdate(Void... values) {
        try {
            JSONObject arr = new JSONObject(result);
            callback.onRegisterTaskCompleted(arr);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
}

