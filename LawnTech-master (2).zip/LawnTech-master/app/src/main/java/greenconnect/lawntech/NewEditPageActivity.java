package greenconnect.lawntech;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.maps.model.LatLng;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

public class NewEditPageActivity extends AppCompatActivity implements NewUserCallback {

    SharedPreferences sharedPref;
    SharedPreferences.Editor editor;
    public static final String TAG = "NewUserActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_user);

        /*TextView myTextView = (TextView) findViewById(R.id.toolbar_title);
        TextView Title = (TextView) findViewById(R.id.textView);
        Typeface typeface = Typeface.createFromAsset(getAssets(), "fonts/Aladin-Regular.ttf");
        myTextView.setTypeface(typeface);
        Title.setTypeface(typeface);


        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowTitleEnabled(false);*/

        Typeface typeface = Typeface.createFromAsset(getAssets(), "fonts/Aladin-Regular.ttf");
        final EditText LawnAddress = (EditText) findViewById(R.id.firstaddress);
        final EditText Lawnname = (EditText) findViewById(R.id.lawnname);
        final EditText Acre = (EditText) findViewById(R.id.acres);
        final TextView titleu = (TextView) findViewById(R.id.title);
        final TextView ptitleu = (TextView) findViewById(R.id.ptitle);
        final TextView t2 = (TextView) findViewById(R.id.title2);
        final EditText nameCards = (EditText) findViewById(R.id.nameCard);
        final EditText CNs = (EditText) findViewById(R.id.CN);
        final EditText SCs = (EditText) findViewById(R.id.SC);
        final EditText ExDs = (EditText) findViewById(R.id.ExD);
        final EditText CardAd = (EditText) findViewById(R.id.cardaddress);
        final EditText citys = (EditText) findViewById(R.id.city);
        final EditText States = (EditText) findViewById(R.id.State);
        final EditText Zips = (EditText) findViewById(R.id.Zip);
        titleu.setTypeface(typeface);
        ptitleu.setTypeface(typeface);
        t2.setTypeface(typeface);

        final EditText email = (EditText) findViewById(R.id.email);
        final EditText fname = (EditText) findViewById(R.id.firstname);
        final Button bRegister = (Button) findViewById(R.id.nubutton);

        bRegister.setTypeface(typeface);
        sharedPref = getSharedPreferences("session", Context.MODE_PRIVATE);
        final String Session = sharedPref.getString("key","");


        final String LawnAddres = LawnAddress.getText().toString();

        final String acres2 = Acre.getText().toString();


        MyApplication app = new MyApplication();

        //init the REST WS query object
        RestFetcher rest = new RestFetcher();
        try {
            InputStream caInput = this.getAssets().open("fulgentcorp.crt");
            rest.initKeyStore(caInput);
            caInput.close();
        } catch (IOException e) {
            Log.e(TAG, "*** initKeyStore error: " + e.getMessage());
        }
        app.setRest(rest);


        bRegister.setOnClickListener(new View.OnClickListener() {


            @Override
            public void onClick(View v) {

                double acre = 0;
                double longitude = Longitude(NewEditPageActivity.this, LawnAddress.getText().toString());
                double latitude = Latitude(NewEditPageActivity.this, LawnAddress.getText().toString());

                editor = sharedPref.edit();
                editor.putString("address", LawnAddress.getText().toString());
                editor.commit();

                MyApplication app = new MyApplication();
                app.initSession();

                RestFetcher rest2 = new RestFetcher();
                try {
                    InputStream caInput = NewEditPageActivity.this.getAssets().open("fulgentcorp.crt");
                    rest2.initKeyStore(caInput);
                    caInput.close();
                } catch (IOException e) {
                    Log.e(TAG, "*** initKeyStore error: " + e.getMessage());
                }


                new NewUserTask(app.getNL_URL(),fname.getText().toString(), latitude, longitude,email.getText().toString(),LawnAddress.getText().toString(),Session,acre, NewEditPageActivity.this, rest2).execute();
            }


        });
    }



    public double Latitude(Context context, String strAddress) {

        Geocoder coder = new Geocoder(context);
        List<Address> address;
        LatLng p1 = null;
        double latitude = 0;

        try {
            // May throw an IOException
            address = coder.getFromLocationName(strAddress, 5);
            if (address == null) {
                return 0;
            }
            Address location = address.get(0);
            location.getLatitude();
            location.getLongitude();

            latitude = location.getLatitude();
            String longitude = Double.toString(location.getLongitude());

            // System.out.println(latitude);


            p1 = new LatLng(location.getLatitude(), location.getLongitude() );

        } catch (IOException ex) {

            ex.printStackTrace();
        }

        return latitude;
    }

    public double Longitude(Context context, String strAddress) {

        Geocoder coder = new Geocoder(context);
        List<Address> address;
        LatLng p1 = null;
        double longitude=0;

        try {
            // May throw an IOException
            address = coder.getFromLocationName(strAddress, 5);
            if (address == null) {
                return 0;
            }
            Address location = address.get(0);
            location.getLatitude();
            location.getLongitude();

            String latitude = Double.toString(location.getLatitude());
            longitude = location.getLongitude();


            p1 = new LatLng(location.getLatitude(), location.getLongitude() );

        } catch (IOException ex) {

            ex.printStackTrace();
        }

        return longitude;
    }

    @Override
    public void onNewUserTaskCompleted(JSONObject response) {

        try {
            boolean success = false;
            //iterate through the result and look for "success" result and the "session_key"

            if (response.has("result")) {
                if (response.get("result").equals("ok")) {

                    success = true;
                    //String username = response.getString("username");
                    Intent intent = new Intent(NewEditPageActivity.this, LoginActivity.class);


                    Toast.makeText(this, "Welcome!, Please Relogin to Complete Registration", Toast.LENGTH_SHORT).show();
                    //Intent intent =  new Intent(LoginActivity.this, MainMap.class);
                    this.startActivity(intent);
                    // Toast.makeText(this, "Login Passed. Please check your credentials", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, "Something went wrong", Toast.LENGTH_SHORT).show();
                }
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }

    }
}