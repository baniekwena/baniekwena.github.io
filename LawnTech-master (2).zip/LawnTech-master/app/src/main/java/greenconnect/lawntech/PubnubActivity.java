package greenconnect.lawntech;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;
import com.google.common.base.Throwables;
import com.pubnub.api.PNConfiguration;
import com.pubnub.api.PubNub;
import com.pubnub.api.callbacks.SubscribeCallback;
import com.pubnub.api.models.consumer.PNStatus;
import com.pubnub.api.models.consumer.pubsub.PNMessageResult;
import com.pubnub.api.models.consumer.pubsub.PNPresenceEventResult;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class PubnubActivity extends AppCompatActivity implements OnMapReadyCallback, RequestMowerCallback, CancelMowerCallback {
    public static final String TAG = PubnubActivity.class.getName();

    SharedPreferences.Editor editor;

    public static final String DATASTREAM_PREFS = "com.pubnub.example.android.datastream.mapexample.DATASTREAM_PREFS";
    public static final String DATASTREAM_UUID = "com.pubnub.example.android.datastream.mapexample.DATASTREAM_UUID";

    public static final String PUBLISH_KEY = "pub-c-7a37901d-d45c-4a3d-9657-3ebb14277622";
    public static final String SUBSCRIBE_KEY = "sub-c-03d30a44-4f0c-11e7-b7ac-02ee2ddab7fe";
    private String CHANNEL_NAME = "";

    private GoogleMap mMap;

    private PubNub mPubNub;

    private SharedPreferences sharedPref;

    private Marker mMarker, hMarker;
    private Polyline mPolyline;

    private int zoom = 0;
    private int arrived = 0;
    private String transid = null;

    private List<LatLng> mPoints = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        sharedPref = getSharedPreferences("session", Context.MODE_PRIVATE);

        MyApplication app = new MyApplication();
        app.initSession();

        RestFetcher rest2 = new RestFetcher();
        try {
            InputStream caInput = PubnubActivity.this.getAssets().open("fulgentcorp.crt");
            rest2.initKeyStore(caInput);
            caInput.close();
        } catch (IOException e) {

        }

       // RunAnimation();



        String Session = sharedPref.getString("key", "");


        new RequestMowerTask(app.getRM_URL(), Session, PubnubActivity.this, rest2).execute();

       /* mSharedPrefs = getSharedPreferences(DATASTREAM_PREFS, MODE_PRIVATE);
        if (!mSharedPrefs.contains(DATASTREAM_UUID)) {
            Intent toLogin = new Intent(this, LoginActivity.class);
            startActivity(toLogin);
            return;
        }*/

       System.out.println("Hi there");
        setContentView(R.layout.activity_pubnub);

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.pnmap);
        mapFragment.getMapAsync(this);

        final Button cancel = (Button) findViewById(R.id.btCancel);

        cancel.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // Perform action on click
                if(arrived == 0) {
                    String Session = sharedPref.getString("key", "");
                    transid = sharedPref.getString("transid", "");

                    MyApplication app = new MyApplication();
                    app.initSession();

                    RestFetcher rest2 = new RestFetcher();
                    try {
                        InputStream caInput = PubnubActivity.this.getAssets().open("fulgentcorp.crt");
                        rest2.initKeyStore(caInput);
                        caInput.close();
                    } catch (IOException e) {

                    }

                    new CancelMowerTask(app.getCMURL(), Session, transid, PubnubActivity.this, rest2).execute();


                    Intent activityChangeIntent = new Intent(PubnubActivity.this, MainMap.class);

                    // currentContext.startActivity(activityChangeIntent);
                    PubnubActivity.this.startActivity(activityChangeIntent);

                }
                else {
                    Toast.makeText(PubnubActivity.this, "Can't Cancel, Mow Already Started", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    /*public void setTextMS(){

        TextView MOW = (TextView) findViewById(R.id.Mow);
        MOW.
    }*/

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
    }

    private final void initPubNub() {
        PNConfiguration config = new PNConfiguration();

        config.setPublishKey(PUBLISH_KEY);
        config.setSubscribeKey(SUBSCRIBE_KEY);
        config.setSecure(true);

        this.mPubNub = new PubNub(config);

        this.mPubNub.addListener(new SubscribeCallback() {
            @Override
            public void status(PubNub pubnub, PNStatus status) {
                System.out.println("docrob is cool"+CHANNEL_NAME);

                // no status handler for simplicity
            }


            @Override
            public void message(PubNub pubnub, PNMessageResult message) {
                try {
                    System.out.println("ppop");
                    Log.v(TAG, JsonUtil.asJson(message));
                    System.out.println("ppop2");
                    String pleasework = message.getMessage().toString();
                    JSONArray arr = new JSONArray(pleasework);
                    JSONObject inarr = arr.getJSONObject(0);
                    System.out.println("Message: "+pleasework);

                   //Map<String, String> map = JsonUtil.convert(message.getMessage(), LinkedHashMap.class);
                   if(inarr.has("message")){
                       if(inarr.get("message").equals("Mow completed")){
                           String Mowername = inarr.getString("user_name");
                           String Payment = inarr.getString("payment_result");
                           System.out.println("mower name: "+ Mowername);
                           runOnUiThread(new Runnable() {
                               @Override
                               public void run() {
                                   TextView mow = (TextView) findViewById(R.id.Mow);
                                   mow.setText("Mow Completed");
                               }

                           });

                           Intent intent = new Intent(PubnubActivity.this, VerifyAndRate.class);
                           intent.putExtra("Mowername", Mowername);
                           intent.putExtra("Payment", Payment);
                           startActivity(intent);
                       }
                       else if(inarr.get("message").equals("Mow started")) {
                           //setTextMS();
                           runOnUiThread(new Runnable() {
                               @Override
                               public void run() {
                                   TextView mow = (TextView) findViewById(R.id.Mow);
                                   mow.setText("Mow Started");
                               }

                            });
                           arrived = 1;
                       }
                   }
                   if (inarr.has("lat")) {
                        String lat = inarr.getString("lat");
                        // String lat = "0";
                        System.out.println("I really hope this works!!: "+ pleasework);
                        //String lat = "0";
                        System.out.println("bryan is long"+lat);
                        String lng = inarr.getString("lng");
                        // String lng = "0";
                        System.out.println("bryan is cool" +lng);;

                        updateLocation(new LatLng(Double.parseDouble(lat), Double.parseDouble(lng)));
                    }
                    else{
                       //
                        return;

                    }

                    //Toast.makeText(PubnubActivity.this, "Mow Complete", Toast.LENGTH_SHORT).show();

                } catch (Exception e) {
                    System.out.println("json failed for some reason");
                    throw Throwables.propagate(e);
                }
            }

            @Override
            public void presence(PubNub pubnub, PNPresenceEventResult presence) {
                System.out.println("herrrrrrrr");
                // no presence handler for simplicity
            }
        });


        this.mPubNub.subscribe().channels(Arrays.asList(CHANNEL_NAME)).execute();
    }



    private void updateLocation(final LatLng location) {
        this.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                mPoints.add(location);

                if (PubnubActivity.this.mMarker != null) {
                    PubnubActivity.this.mMarker.setPosition(location);
                } else {
                    PubnubActivity.this.mMarker = mMap.addMarker(new MarkerOptions().position(location).title("Mower").icon(BitmapDescriptorFactory.fromResource(R.drawable.mower_machinethree)));
                }

                if (PubnubActivity.this.mPolyline != null) {
                    PubnubActivity.this.mPolyline.setPoints(mPoints);
                } else {
                    PubnubActivity.this.mPolyline = mMap.addPolyline(new PolylineOptions().color(Color.BLUE).addAll(mPoints));
                }




                String address = sharedPref.getString("address", "");
                LatLng CurrentLawn = getLocationFromAddress(PubnubActivity.this, address);
                PubnubActivity.this.hMarker = mMap.addMarker(new MarkerOptions().position(CurrentLawn).title("Your Lawn").icon(BitmapDescriptorFactory.defaultMarker(305)));

                if(zoom == 0) {
                    LatLngBounds.Builder builder = new LatLngBounds.Builder();

                    builder.include(mMarker.getPosition());
                    builder.include(hMarker.getPosition());

                    LatLngBounds bounds = builder.build();
                    int width = getResources().getDisplayMetrics().widthPixels;
                    int height = getResources().getDisplayMetrics().heightPixels;
                    int padding = (int) (width * 0.25);

                    CameraUpdate cu = CameraUpdateFactory.newLatLngBounds(bounds, width, height, padding);
                    mMap.moveCamera(cu);

                    zoom = 1;
                }
            }
        });
    }

    public LatLng getLocationFromAddress(Context context, String strAddress) {

        Geocoder coder = new Geocoder(context);
        List<Address> address;
        LatLng p1 = null;

        try {
            // May throw an IOException
            address = coder.getFromLocationName(strAddress, 5);
            if (address == null) {
                return null;
            }
            Address location = address.get(0);
            location.getLatitude();
            location.getLongitude();

            String latitude = Double.toString(location.getLatitude());
            String longitude = Double.toString(location.getLongitude());

            //System.out.println(latitude);


            p1 = new LatLng(location.getLatitude(), location.getLongitude() );

        } catch (IOException ex) {

            ex.printStackTrace();
        }

        return p1;
    }

    @Override
    public void onRequestMowerTaskCompleted(JSONObject response) {

        try {
            boolean success = false;
            //iterate through the result and look for "success" result and the "session_key"

            if (response.has("result")) {
                if (response.get("result").equals("ok")) {

                    JSONObject rows = response.getJSONObject("rows");

                    String channel = rows.getString("channel");
                    String transid = rows.getString("transaction_id");

                    sharedPref = getSharedPreferences("session", Context.MODE_PRIVATE);
                    editor = sharedPref.edit();
                    editor.putString("channel", channel);
                    editor.commit();

                    editor = sharedPref.edit();
                    editor.putString("transid", transid);
                    editor.commit();

                    CHANNEL_NAME = sharedPref.getString("channel", "");
                    System.out.println("Channel: "+CHANNEL_NAME);

                    //testmap();

                    //Toast.makeText(this, "Mow started", Toast.LENGTH_SHORT).show();
                    initPubNub();
                    //Toast.makeText(this, "Mow finished", Toast.LENGTH_SHORT).show();


                } else {
                    Toast.makeText(this, "Request Failed", Toast.LENGTH_SHORT).show();
                }
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }

    }

   /* private void RunAnimation()
    {


        a.reset();
        TextView tv = (TextView) findViewById(R.id.Mow);
        tv.clearAnimation();
        tv.startAnimation(a);
    }*/

    @Override
    public void onCancelMowerTaskCompleted(JSONObject response) {

        try {
            boolean success = false;
            //iterate through the result and look for "success" result and the "session_key"

            if (response.has("result")) {
                if (response.get("result").equals("ok")) {


                } else {
                    Toast.makeText(this, "Mower Cancel Completed", Toast.LENGTH_SHORT).show();
                }
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }

    }


}