package greenconnect.lawntech;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

public class MainMap extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener,  GetMowerCallback, OnMapReadyCallback{

    private NavigationView navigationView;
    private DrawerLayout drawer;
    private View navHeader;
    private ImageView imgNavHeaderBg, imgProfile;
    private TextView txtName, txtWebsite, txtaddress, txtprice;
    private Toolbar toolbar;
    private Button RequestMow;
    private FloatingActionButton fab;
    private Spinner spinner;
    SharedPreferences sharedPref;
    SharedPreferences.Editor editor;
    private ArrayList<String> mowers = new ArrayList<String>();

    private GoogleMap mMap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        sharedPref = getSharedPreferences("session", Context.MODE_PRIVATE);
        MyApplication app = new MyApplication();
        app.initSession();

        RestFetcher rest2 = new RestFetcher();
        try {
            InputStream caInput = MainMap.this.getAssets().open("fulgentcorp.crt");
            rest2.initKeyStore(caInput);
            caInput.close();
        } catch (IOException e) {

        }

        String Session = sharedPref.getString("key", "");


        new GetMowerLocationTask(app.getML_URL(), Session, MainMap.this, rest2).execute();


        setContentView(R.layout.activity_main_map);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        TextView myTextView = (TextView) findViewById(R.id.toolbar_title);
        Typeface typeface = Typeface.createFromAsset(getAssets(), "fonts/Aladin-Regular.ttf");
        myTextView.setTypeface(typeface);

        drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        navigationView = (NavigationView) findViewById(R.id.nav_view);
        fab = (FloatingActionButton) findViewById(R.id.fab);

        final Button RequestMow = (Button) findViewById(R.id.request_button);

        ImageButton refresh = (ImageButton) findViewById(R.id.refreshbuttn);

        refresh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent Refresh = new Intent(MainMap.this, MainMap.class);
                MainMap.this.startActivity(Refresh);
                finish();
            }
        });



       // String Session = sharedPref.getString("key","");
        System.out.println("this"+Session);



        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.setDrawerListener(toggle);
        toggle.syncState();

        RequestMow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = getIntent();
                Intent RequestIntent = new Intent(MainMap.this, RequestMowerActivity.class);
                String address = intent.getStringExtra("address");
                String price = intent.getStringExtra("price");
                RequestIntent.putExtra("address", address);
                RequestIntent.putExtra("price", price);
                MainMap.this.startActivity(RequestIntent);
            }
        });

        navHeader = navigationView.getHeaderView(0);
        txtName = (TextView) navHeader.findViewById(R.id.name);
       // txtName.setTypeface(typeface);
        txtaddress = (TextView) findViewById(R.id.address);
        //txtaddress.setTypeface(typeface);
        txtprice = (TextView) findViewById(R.id.price);
        //txtprice.setTypeface(typeface);

        txtWebsite = (TextView) navHeader.findViewById(R.id.website);




        Intent intent = getIntent();
        //String Adress = "1600 Pennsylvania Ave NW, Washington, DC 20500";
        String name = sharedPref.getString("name","");
        if(name.isEmpty()){name = "choose name";};
        String address = sharedPref.getString("address", "");
        if(address.isEmpty()){address = "White House";};
        String price = sharedPref.getString("price", "");
        if(price.isEmpty()){price = "choose price";};

        //Intent intent2 = new Intent(MainMap.this, EditProfileActivity.class);
        //holder.setData(address);
       // intent2.putExtra("address", address);


        //SharedPreferences myprefs= this.getSharedPreferences("user", MODE_WORLD_READABLE);
       // myprefs.edit().putString("session_id", address).apply();

//        address = String.valueOf(address.charAt(0)).toUpperCase() + address.substring(1, address.length());

        txtName.setText("Welcome "+ name.toUpperCase() +"!");
        txtaddress.setText("Current Address: "+address.toUpperCase());
        txtprice.setText("Price: "+price);
        //txtWebsite.setText("www.androidhive.info");




        //getSupportActionBar().hide();
        //getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowTitleEnabled(false);

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main_map, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            Intent logout = new Intent(MainMap.this, LoginActivity.class)
                    .setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            finish();
            logout.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            logout.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(logout);
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();
        Intent intent = getIntent();

        if (id == R.id.nav_view_my_Lawns) {
            Intent tIntent = new Intent(MainMap.this, ViewMyLawns.class);
            String address = sharedPref.getString("address", "");
            tIntent.putExtra("address", address);
            MainMap.this.startActivity(tIntent);
            // Handle the camera action
        } else if (id == R.id.nav_RM) {
            Intent intent2 = getIntent();
            Intent RequestIntent = new Intent(MainMap.this, RequestMowerActivity.class);
            String address = sharedPref.getString("address", "");
            String price = intent2.getStringExtra("price");
            RequestIntent.putExtra("address", address);
            RequestIntent.putExtra("price", price);
            MainMap.this.startActivity(RequestIntent);

        } else if (id == R.id.nav_add_lawns) {
            Intent intent2 = getIntent();
            Intent AddLawnIntent = new Intent(MainMap.this, AddLawnActivity.class);
            String address = sharedPref.getString("address", "");
            String price = intent2.getStringExtra("price");
            AddLawnIntent.putExtra("address", address);
            AddLawnIntent.putExtra("price", price);
            MainMap.this.startActivity(AddLawnIntent);

        }else if (id == R.id.nav_edit_profile) {
            Intent intent2 = getIntent();
            Intent EditProfileIntent = new Intent(MainMap.this, NewUserActivity.class);
            String address = sharedPref.getString("address", "");
            String name = intent2.getStringExtra("name");
            EditProfileIntent.putExtra("address", address);
            EditProfileIntent.putExtra("name", name);
            MainMap.this.startActivity(EditProfileIntent);

        } else if (id == R.id.nav_faq) {

            Intent faq = new Intent(MainMap.this, FAQ.class);
            MainMap.this.startActivity(faq);

        } else if (id == R.id.nav_tou) {

        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;





        Intent intent2 = getIntent();
        //String Adress = "1600 Pennsylvania Ave NW, Washington, DC 20500";
        String address = sharedPref.getString("address", "");

        if(address.isEmpty()){address = "White House";};

        String mlat = "0";
        String mlong = "0";

        // Add a marker in Sydney and move the camera
        String Lat = Latitude(this, address);
        String Lon = Longitude(this, address);
        LatLng CurrentLawn = getLocationFromAddress(this, address);
        mMap.addMarker(new MarkerOptions().position(CurrentLawn).title("Your Lawn").icon(BitmapDescriptorFactory.defaultMarker(305)));
        //mowers.add("you suck");
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(CurrentLawn, 10));
        int i;
        for(i = 0; i < mowers.size(); i+=2) {
            String lat = mowers.get(i);
            String longi = mowers.get(i + 1);

            //for(String d:mowers){
            //System.out.println("mower location = " + d);
            //}


            double dmlat = Double.parseDouble(lat);


            double dmlong = Double.parseDouble(longi);

            System.out.println("Latitude: " + Lat + "\n");
            System.out.println("Longitude: " + Lon + "\n");


            LatLng MowerLocation = new LatLng(dmlat, dmlong);

            mMap.addMarker(new MarkerOptions().position(MowerLocation).title("Mower Lawn").icon(BitmapDescriptorFactory.fromResource(R.drawable.mower_machinethree)));

        }
    }


    public LatLng getLocationFromAddress(Context context, String strAddress) {

        Geocoder coder = new Geocoder(context);
        List<Address> address;
        LatLng p1 = null;

        try {
            // May throw an IOException
            address = coder.getFromLocationName(strAddress, 5);
            if (address == null) {
                return null;
            }
            Address location = address.get(0);
            location.getLatitude();
            location.getLongitude();

            String latitude = Double.toString(location.getLatitude());
            String longitude = Double.toString(location.getLongitude());

            //System.out.println(latitude);


            p1 = new LatLng(location.getLatitude(), location.getLongitude() );

        } catch (IOException ex) {

            ex.printStackTrace();
        }

        return p1;
    }

    public String getLat(String lat){
        return lat;
    }

    public String Latitude(Context context, String strAddress) {

        Geocoder coder = new Geocoder(context);
        List<Address> address;
        LatLng p1 = null;
        String latitude = null;

        try {
            // May throw an IOException
            address = coder.getFromLocationName(strAddress, 5);
            if (address == null) {
                return null;
            }
            Address location = address.get(0);
            location.getLatitude();
            location.getLongitude();

            latitude = Double.toString(location.getLatitude());
            String longitude = Double.toString(location.getLongitude());

           // System.out.println(latitude);


            p1 = new LatLng(location.getLatitude(), location.getLongitude() );

        } catch (IOException ex) {

            ex.printStackTrace();
        }

        return latitude;
    }

    public String Longitude(Context context, String strAddress) {

        Geocoder coder = new Geocoder(context);
        List<Address> address;
        LatLng p1 = null;
        String longitude=null;

        try {
            // May throw an IOException
            address = coder.getFromLocationName(strAddress, 5);
            if (address == null) {
                return null;
            }
            Address location = address.get(0);
            location.getLatitude();
            location.getLongitude();

            String latitude = Double.toString(location.getLatitude());
            longitude = Double.toString(location.getLongitude());


            p1 = new LatLng(location.getLatitude(), location.getLongitude() );

        } catch (IOException ex) {

            ex.printStackTrace();
        }

        return longitude;
    }

    @Override
    public void onGetMowerTaskCompleted(JSONObject response) {

        try {
            JSONArray rows = response.getJSONArray("rows");


                /*for (int i = 0; i < rows.length(); i++) {
                    JSONObject o = rows.getJSONObject(i);
                    String MowerName = o.getString("user_name");
                    String mlatitude = o.getString("latitude");
                    String mlongitude = o.getString("longitude");
                    mlocate.add(mlatitude);
                    mlocate.add(mlongitude);
                }*/

            for (int i = 0; i < rows.length(); i++) {
                JSONObject o = rows.getJSONObject(i);
                String MowerName = o.getString("user_name");
                String mlatitude = o.getString("latitude");
                String mlongitude = o.getString("longitude");
                mowers.add(mlatitude);
                mowers.add(mlongitude);

            }

            for(String d: mowers){
                System.out.print(d);
            }


            // JSONObject n = o.getJSONObject("location_fields");
            //  String name = n.getString("name");
            // System.out.println(name+"\n");
            //}


        } catch (JSONException e) {
            e.printStackTrace();
        }

    }

}

