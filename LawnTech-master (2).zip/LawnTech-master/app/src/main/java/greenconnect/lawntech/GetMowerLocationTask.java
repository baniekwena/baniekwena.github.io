package greenconnect.lawntech;

import android.os.AsyncTask;
import android.util.Log;
import android.os.AsyncTask;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
/**
 * Created by p4050 on 7/23/2017.
 */





public class GetMowerLocationTask extends AsyncTask<Void, Void, Void> {
    private static final String TAG = "LoginTask";
    private String wsURL = "";
    private GetMowerCallback callback;
    private String result;
    private String login = "";
    private String password = "";
    private String pw_hash = "";
    private String appCode = "";

    private RestFetcher rest = null;

    public GetMowerLocationTask(String ws, String l, GetMowerCallback cb, RestFetcher r){
        //GetLocationCallback cb, RestFetcher r) {
        wsURL = ws;
        callback = cb;
        login = l;
        rest = r;
    }

    protected Void doInBackground(Void... params) {
        try {
            JSONArray req = new JSONArray();
            JSONObject obj = new JSONObject();
            // obj.put("action", "login");
            // req.put(obj);
            // obj = new JSONObject();
            obj.put("login", login);
            // req.put(obj);
            //obj = new JSONObject();
            obj.put("pw_hash", pw_hash);
            //req.put(obj);
            // obj = new JSONObject();
            obj.put("session_type", "session_key");
            //req.put(obj);

            if(rest == null)
                System.out.println("rest is null");

            this.result = rest.getUrl(wsURL + login +"&json={\"location_id\":1,\"distance\":15}");
            System.out.println(wsURL + login +"&json={\"location_id\":1,\"distance\":15}");
            //System.out.println("HEllo");
            publishProgress();
        } catch (Exception e) {
            Log.e(TAG, "Failed to fetch URL: ", e);
            // System.out.println(req.toString());
        }
        return null;
    }

    //onProgressUpdate runs on the UI thread
   @Override
    protected void onProgressUpdate(Void... values) {
        try {
            //JSONObject arr = new JSONObject(result);
            JSONObject arr = new JSONObject(result);
            callback.onGetMowerTaskCompleted(arr);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
}


