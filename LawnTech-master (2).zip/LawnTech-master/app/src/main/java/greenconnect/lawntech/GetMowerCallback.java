package greenconnect.lawntech;

/**
 * Created by p4050 on 6/29/2017.
 */

import org.json.JSONObject;

public interface GetMowerCallback {
    void onGetMowerTaskCompleted(JSONObject result);
}