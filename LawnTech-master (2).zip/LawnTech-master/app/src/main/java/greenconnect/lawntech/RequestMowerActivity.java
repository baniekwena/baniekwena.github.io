package greenconnect.lawntech;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.location.Address;
import android.location.Geocoder;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

public class RequestMowerActivity extends AppCompatActivity implements OnMapReadyCallback, GetMowerCallback{

    private GoogleMap mMap;
    private Spinner spinner;
    private ArrayList<String> mowers = new ArrayList<String>();

    SharedPreferences sharedPref;
    SharedPreferences.Editor editor;



    private TextView txtName, txtWebsite, txtaddress, txtprice;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        sharedPref = getSharedPreferences("session", Context.MODE_PRIVATE);
        super.onCreate(savedInstanceState);

        MyApplication app = new MyApplication();
        app.initSession();

        RestFetcher rest2 = new RestFetcher();
        try {
            InputStream caInput = RequestMowerActivity.this.getAssets().open("fulgentcorp.crt");
            rest2.initKeyStore(caInput);
            caInput.close();
        } catch (IOException e) {

        }

        String Session = sharedPref.getString("key", "");


        new GetMowerLocationTask(app.getML_URL(), Session, RequestMowerActivity.this, rest2).execute();

        setContentView(R.layout.activity_request_mower);
        Intent intent = getIntent();

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        TextView myTextView = (TextView) findViewById(R.id.toolbar_title);
        Typeface typeface = Typeface.createFromAsset(getAssets(), "fonts/Aladin-Regular.ttf");
        myTextView.setTypeface(typeface);

        final String address222 = intent.getStringExtra("address");

        final Button RequestMow = (Button) findViewById(R.id.srequest_button);

        spinner = (Spinner) findViewById(R.id.sLawnSpinner);
        String [] Lawns = {"", "Grass Overgrown", "Objects To Move", "Dead Body", "Wear a Bulletproof Vest!", "Beware of Animals" };
        ArrayAdapter adapter2 = new ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, Lawns);
        spinner.setAdapter(adapter2);



        //RequestMow.setTypeface(typeface);


        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.smap);
        mapFragment.getMapAsync(this);

        final ImageButton refresh = (ImageButton) findViewById(R.id.refreshbutt);

        refresh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent Refresh = new Intent(RequestMowerActivity.this, RequestMowerActivity.class);
                RequestMowerActivity.this.startActivity(Refresh);
                finish();
            }
        });


        RequestMow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(mowers.isEmpty()) {
                    Toast.makeText(RequestMowerActivity.this, "No mowers in the area.", Toast.LENGTH_SHORT).show();
                    return;
                }
                Intent RequestIntent = new Intent(RequestMowerActivity.this, PubnubActivity.class);
                RequestMowerActivity.this.startActivity(RequestIntent);
            }
        });

        txtaddress = (TextView) findViewById(R.id.saddress);
        txtprice = (TextView) findViewById(R.id.sprice);
       // txtaddress.setTypeface(typeface);
        //txtprice.setTypeface(typeface);

        Intent intent2 = getIntent();
        //String Adress = "1600 Pennsylvania Ave NW, Washington, DC 20500";
       // String name = intent.getStringExtra("name");
        //String address = intent.getStringExtra("address");
        String price = sharedPref.getString("price", "");

        String address = sharedPref.getString("address", "");


        txtprice.setText("Price: "+price);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;





        Intent intent2 = getIntent();
        //String Adress = "1600 Pennsylvania Ave NW, Washington, DC 20500";
        String address = sharedPref.getString("address", "");
        if(address.isEmpty()){
            address = "White House";
        }
        txtaddress.setText("Current Address: "+address.toUpperCase());
        String mlat = "0";
        String mlong = "0";

        // Add a marker in Sydney and move the camera
        String Lat = Latitude(this, address);
        String Lon = Longitude(this, address);
        LatLng CurrentLawn = getLocationFromAddress(this, address);
        mMap.addMarker(new MarkerOptions().position(CurrentLawn).title("Your Lawn").icon(BitmapDescriptorFactory.defaultMarker(305)));
        //mowers.add("you suck");
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(CurrentLawn, 10));
        int i;
        for(i = 0; i < mowers.size(); i+=2) {
            String lat = mowers.get(i);
            String longi = mowers.get(i + 1);

            //for(String d:mowers){
            //System.out.println("mower location = " + d);
            //}


            double dmlat = Double.parseDouble(lat);


            double dmlong = Double.parseDouble(longi);

            System.out.println("Latitude: " + Lat + "\n");
            System.out.println("Longitude: " + Lon + "\n");


            LatLng MowerLocation = new LatLng(dmlat, dmlong);

            mMap.addMarker(new MarkerOptions().position(MowerLocation).title("Mower").icon(BitmapDescriptorFactory.fromResource(R.drawable.mower_machinethree)));

        }
    }


    public LatLng getLocationFromAddress(Context context, String strAddress) {

        Geocoder coder = new Geocoder(context);
        List<Address> address;
        LatLng p1 = null;

        try {
            // May throw an IOException
            address = coder.getFromLocationName(strAddress, 5);
            if (address == null) {
                return null;
            }
            Address location = address.get(0);
            location.getLatitude();
            location.getLongitude();

            p1 = new LatLng(location.getLatitude(), location.getLongitude() );

        } catch (IOException ex) {

            ex.printStackTrace();
        }

        return p1;
    }

    public String Latitude(Context context, String strAddress) {

        Geocoder coder = new Geocoder(context);
        List<Address> address;
        LatLng p1 = null;
        String latitude = null;

        try {
            // May throw an IOException
            address = coder.getFromLocationName(strAddress, 5);
            if (address == null) {
                return null;
            }
            Address location = address.get(0);
            location.getLatitude();
            location.getLongitude();

            latitude = Double.toString(location.getLatitude());
            String longitude = Double.toString(location.getLongitude());

            // System.out.println(latitude);


            p1 = new LatLng(location.getLatitude(), location.getLongitude() );

        } catch (IOException ex) {

            ex.printStackTrace();
        }

        return latitude;
    }

    public String Longitude(Context context, String strAddress) {

        Geocoder coder = new Geocoder(context);
        List<Address> address;
        LatLng p1 = null;
        String longitude=null;

        try {
            // May throw an IOException
            address = coder.getFromLocationName(strAddress, 5);
            if (address == null) {
                return null;
            }
            Address location = address.get(0);
            location.getLatitude();
            location.getLongitude();

            String latitude = Double.toString(location.getLatitude());
            longitude = Double.toString(location.getLongitude());


            p1 = new LatLng(location.getLatitude(), location.getLongitude() );

        } catch (IOException ex) {

            ex.printStackTrace();
        }

        return longitude;
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

    @Override
    public void onGetMowerTaskCompleted(JSONObject response) {
        try {
            JSONArray rows = response.getJSONArray("rows");


                /*for (int i = 0; i < rows.length(); i++) {
                    JSONObject o = rows.getJSONObject(i);
                    String MowerName = o.getString("user_name");
                    String mlatitude = o.getString("latitude");
                    String mlongitude = o.getString("longitude");
                    mlocate.add(mlatitude);
                    mlocate.add(mlongitude);
                }*/

            for (int i = 0; i < rows.length(); i++) {
                JSONObject o = rows.getJSONObject(i);
                String MowerName = o.getString("user_name");
                String mlatitude = o.getString("latitude");
                String mlongitude = o.getString("longitude");
                mowers.add(mlatitude);
                mowers.add(mlongitude);

            }

            for(String d: mowers){
                System.out.print(d);
            }


            // JSONObject n = o.getJSONObject("location_fields");
            //  String name = n.getString("name");
            // System.out.println(name+"\n");
            //}


        } catch (JSONException e) {
            e.printStackTrace();
        }

    }
}

