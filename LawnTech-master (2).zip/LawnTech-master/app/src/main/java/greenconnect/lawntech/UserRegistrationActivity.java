package greenconnect.lawntech;

import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;


public class UserRegistrationActivity extends AppCompatActivity implements RegisterCallback {

    public static final String TAG = "RegistrationActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_registration);

        final EditText etUserName = (EditText) findViewById(R.id.userName);
        final EditText etPassword = (EditText) findViewById(R.id.password);
        final Button bRegister = (Button) findViewById(R.id.submitButton);

        MyApplication app = new MyApplication();

        //init the REST WS query object
        RestFetcher rest = new RestFetcher();
        try {
            InputStream caInput = this.getAssets().open("fulgentcorp.crt");
            rest.initKeyStore(caInput);
            caInput.close();
        } catch (IOException e) {
            Log.e(TAG, "*** initKeyStore error: " + e.getMessage());
        }
        app.setRest(rest);


        bRegister.setOnClickListener(new View.OnClickListener() {

            String pass = etPassword.getText().toString();
            @Override
            public void onClick(View v) {
                MyApplication app = new MyApplication();
                app.initSession();

                RestFetcher rest2 = new RestFetcher();
                try {
                    InputStream caInput = UserRegistrationActivity.this.getAssets().open("fulgentcorp.crt");
                    rest2.initKeyStore(caInput);
                    caInput.close();
                } catch (IOException e) {
                    Log.e(TAG, "*** initKeyStore error: " + e.getMessage());
                }

                if (etPassword.getText().toString().matches("")) {
                    Toast.makeText(UserRegistrationActivity.this, "Password cannot be blank", Toast.LENGTH_SHORT).show();
                    return;

                }
                new RegisterTask(app.getWRURL(), etUserName.getText().toString(), etPassword.getText().toString(), UserRegistrationActivity.this, rest2).execute();
            }


        });
    }

    @Override
    public void onRegisterTaskCompleted(JSONObject response) {

//
        try {
            boolean success = false;
            //iterate through the result and look for "success" result and the "session_key"

            if (response.has("result")) {
                if (response.get("result").equals("ok")) {

                    success = true;
                    //String username = response.getString("username");
                    Intent intent = new Intent(UserRegistrationActivity.this, LoginActivity.class);


                    Toast.makeText(this, "Registration Successful", Toast.LENGTH_SHORT).show();
                    //Intent intent =  new Intent(LoginActivity.this, MainMap.class);
                    this.startActivity(intent);
                    // Toast.makeText(this, "Login Passed. Please check your credentials", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, "User Registration Failed", Toast.LENGTH_SHORT).show();
                }
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }

    }
}
