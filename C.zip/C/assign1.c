#include <stdio.h>
#include <stdlib.h>


int main(){

int n, j, k, l,u;	

	

FILE *f = fopen("file.pgm", "w");
if (f == NULL)
{
    printf("Error opening file!\n");
    exit(1);
}


const char *text = "P2";
fprintf(f, "%s\n", text);
int bound=100;
int Width = 800;
int Height = 800;
int MaxGray = 255;
int black = 0;
fprintf(f, "%d %d\n", Width, Height);
fprintf(f, "%d\n", MaxGray);

for(j=0; j<400; j++){

	for(l=0; l<bound; l++){
	
	for(k=0; k<4; k++){

		for(n=0; n<bound; n++){
		fprintf(f, "%d ", black);
		}
			for(n=0; n<bound; n++){
		fprintf(f, "%d ", MaxGray);
			}
			fprintf(f, "\n");
	}
	fprintf(f, "\n");
}
for(u=0; u<bound; u++){

	for(k=0; k<4; k++){

		
			for(n=0; n<bound; n++){
		fprintf(f, "%d ", MaxGray);
			}
			for(n=0; n<bound; n++){
		fprintf(f, "%d ", black);
		}
		fprintf(f, "\n");
}
	fprintf(f,"\n");
}
}

fclose(f);

return 0;
}
