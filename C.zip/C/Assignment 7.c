#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <stdbool.h>

#define MAXV 100

typedef  struct  edgenode {
   int y;			
   int w; //weight
   struct  edgenode  *next;
} edgenodeT;

typedef struct {
   edgenodeT *edges[MAXV+1];
   int degree[MAXV+1];
   int nvertices;
   int nedges;
   bool directed;
} graphT;

initialize_graph(graphT *g, bool directed)
{
   int i;
   g->nvertices = 0;
   g->nedges = 0;
   g->directed = directed;

   for (i=1; i<=MAXV; i++) {
      g->edges[i] = NULL;
	g->degree[i] = 0;
   }
}

insert_edge(graphT *g, int x, int y, int w, bool directed)
{
   edgenodeT *pe;
   pe = malloc(sizeof(edgenodeT)); // check if NULL
   pe->w = w;
   pe->y = y;

   pe->next = g->edges[x];   
   g->edges[x] = pe;

   g->degree[x]++;
   if (directed == false)
       insert_edge(g, y, x, w, true);
}


read_graph(graphT *g, bool directed)
{
   int i;
   int n,m;
   int x, y, w;
 
   scanf("%d %d", &n, &m);
   g->nvertices=n; g->nedges=m;
   for (i=1; i<=m; i++) {
      scanf("%d %d %d", &x, &y, &w);
      insert_edge(g, x, y, w, directed);
   }
}

print_graph(graphT *g)
{
   edgenodeT *pe;
   int i;
   for(i=1; i<=g->nvertices; i++) {
      printf("Node %d: ", i);
      pe = g->edges[i];
      while(pe){
          printf(" %d %d", pe->y, pe->w);
	     pe = pe->next;
      }
      printf("\n");
   }
}


int main() 
{
	FILE *fp;
  	graphT   myg1, *myg2;
  	int v,x,k,l,y,w, e, d, n,z, o;
  	char ch, file_name[25];
  	
  	myg2 = (graphT *) malloc(sizeof(graphT));
  	if(myg2==NULL) {
     printf("no memory");
     exit(-1);
  }     // myg2 = New(graphT *);
  initialize_graph(&myg1, true);

  initialize_graph(myg2, false);
  	
  	 printf("Enter the name of file you wish to see\n");
   gets(file_name);
 
   fp = fopen(file_name,"r"); // read mode
 
   if( fp == NULL )
   {
      perror("Error while opening the file.\n");
      exit(EXIT_FAILURE);
   }
 
  
   
   for(e=0; e<1;e++){
   	
   	for(d=0; d<1; d++){
   		fscanf(fp, "%d", &n);
	   }
   	for(o=1; o<2; o++){
   		fscanf(fp, "%d", &z);
	   }
   	
   	
   }
   
   for(v=1; v<z; v++){
   	
   
   for(k=0; k<1; k++)
	{
		fscanf(fp, "%d", &x );
	}
	
	for(l=1; l<2; l++)
	{
		fscanf(fp, "%d", &y );
	}
	
	insert_edge(&myg1, x, y, 1, false);
}
  
   
   
if(z==(n-1))
printf("This graph belong to a tree");
if(z!=(n-1))
printf("This graph does not belong to a tree");
  
   
}

