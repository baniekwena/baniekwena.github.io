#include <stdio.h>
#include <stdlib.h>


struct nodeT {
  int key;
  struct nodeT *left, *right;
};
typedef struct nodeT nodeT;
typedef nodeT *treeT;

 
void InsertNode(nodeT  **tptr, int key) 
{
  nodeT  *tmp;
  tmp=*tptr;

  if (tmp == NULL) {
    tmp=(nodeT *)malloc(sizeof(nodeT));
    tmp->key = key;
    tmp->left=tmp->right=NULL;
    *tptr=tmp;
    return;
  }
  if (key < tmp->key) {
    InsertNode(&tmp->left, key);
  } else if (key> tmp->key ){
    InsertNode(&tmp->right, key);
  }
}

void DisplayTree(nodeT *t)
{
  if (t != NULL) {
    DisplayTree(t->left);
    printf("%d ", t->key);
    DisplayTree(t->right);
  }
}




void printSideways(nodeT *t, int d) {
	int i;
    if (t == NULL) 
    return;
        printSideways(t->right, d+1);
        for(i =0; i<=d; ++i)
        printf("\t");
		printf("%d\n" ,t->key);
	
        printSideways(t->left, d+1);
    
}

 
 
int main()
{
  int i,x, n, b;
  nodeT   *tt1, **tt2,*tt3;

  tt1 = NULL;
  tt2 = &tt1;
  
  printf("Enter desired tree size: ");
  scanf("%d", &n);
  
  printf("\nEnter %d numbers: ", n);
  
  for(i=0; i< n; i++)
  {
  	scanf("%d", &b);
  	InsertNode(tt2, b);
  }

  printf("\nDisplaying Tree...\n");
  DisplayTree(tt1);
  printf("\n");
  printf("\nPrinting sideways...\n");
  printSideways(tt1,0);
  

  
}
