/*  Assignment 5
 *  Name:
 *  Partner's name:
 *  CS 1713 Summer 2015
 */

#include <stdio.h>
#include <string.h>

/*
`*  Checks whether the characters from position first to position last of the string str form a palindrome.
 *  If it is palindrome it returns 1.  Otherwise it returns 0.
 */
int isPalindrome(int first, int last, char* str)
{

}

/*
`*  Find and print the largest palindrome found in the string str.  Uses isPalindrome as a helper function.
 */
void largestPalindrome(char* str)
{

}

/*
`*  Do not modify this code.
 */
int main(void)
{
    int i = 0;
    /* you can change these strings to other test cases but please change them back before submitting your code */
    char *str1 = "ABCBACDCBAAB";
    char *str2 = "ABCBAHELLOHOWRACECARAREYOUIAMAIDOINEVERODDOREVENNGGOOD";

    /* test easy example */
    printf("Test String 1: %s\n",str1);
    largestPalindrome(str1);

    /* test hard example */
    printf("\nTest String 2: %s\n",str2);
    largestPalindrome(str2);

    return 0;
}

