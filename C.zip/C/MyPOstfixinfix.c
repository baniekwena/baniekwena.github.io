#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#define MAX 100

char stack[MAX];
int istack[MAX];
int top = -1;
char pop();
void push(char item);

int prcd(char symbol)
{

    switch(symbol)

{
    case '=': return 2;
	break;
	case '+':
    case '-':return 4;
	break;
    case '*':
    case '/':return 6;
	break;
    case '(':
    case ')':return 1;
	break;
}

}

int isoperator(char symbol)

{
    if(symbol=='+'||symbol=='-'||symbol=='*'||symbol=='/'||symbol=='=')

         return 1;
     else if(symbol==')'||symbol=='(')
          return -1;
     else
           return 0;
}

void convertip(char infix[],char postfix[])

{

      int i,symbol,j=0;
      stack[++top]='#';
      for(i=0;i<strlen(infix);i++)
     {
        symbol=infix[i];
        if(isoperator(symbol)==0)

       {
           postfix[j]=symbol;
           j++;
       }

      else{

         if(symbol=='(')
            push(symbol);
         else if(symbol==')')
         {
             while(stack[top]!='(')
        {
            postfix[j]=pop();
            j++;
        }
        pop();

    }

        else{
            if(prcd(symbol)>prcd(stack[top]))
                  push(symbol);
            else{
                while(prcd(symbol)<=prcd(stack[top]))
            {
                postfix[j]=pop();
                j++;
            }
            push(symbol);

           }

         }

     }

   }

       while(stack[top]!='#')
       {
           postfix[j]=pop();
           j++;
        }
        postfix[j]='\0';

}
long int oper(char c,int op1,int op2)
{
    switch(c)
    {
        case '+':return op2+op1+48;
        case '-':return op2-op1+48;
        case '*':return op2*op1+48;
        case '/':return op2/op1+48;
        default: printf("Invalid operation!!");exit(1);
    }
}

int eval(char postfix[])
{
   int i;
   char c;
   float value ,op1,op2;
   for(i=0;(c=postfix[i])!='\0';i++)
   {
       if(isoperator(postfix[i])==0)
         push(postfix[i]);
       else
       {
           op1=pop();
           op2=pop();
           op1-=48;
           op2-=48;
           value = oper(c,op1,op2) ;
           push(value);
       }
   }

   return (pop()-48);
}

int main()

{
    char infix[20],postfix[20];
    int i;
    char res;
    do
    {

    printf("\nEnter the valid infix string:  ");
    fflush(stdin);
    gets(infix);
    for(i=0;infix[i]!='\0';i++)
    {
        if(isoperator(infix[i])==1 && isoperator(infix[i+1])==1)
           {

            printf("\n\tINPUT ERROR : Invalid Infix Expression !!");
            getch();
            exit(0);

           }

    }
    convertip(infix,postfix);
    printf("The corresponding postfix string is:  ");
    puts(postfix);
    printf("\nThe value of postfix expression : %d",eval(postfix));
    printf("\n\n\tDo you want to continue -[y/n]? ");
    scanf("%c",&res);

    }while(res =='y'||res=='Y');

    return 0;

}

void push(char item)

{
    top++;
    stack[top]=item;
}

char pop()

{
    char a;
    a=stack[top];
    top--;
    return a;
}
