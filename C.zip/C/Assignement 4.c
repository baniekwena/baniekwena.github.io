#include <stdio.h>
#include <stdlib.h>

struct node{
	int key;
	int count;
	struct node *left, *right;
	
};
typedef struct node node;

void InsertNode(node  **tptr, int key) 
{
  node  *tmp;
  tmp=*tptr;

  if (tmp == NULL) {
    tmp=(node *)malloc(sizeof(node));
    tmp->key = key;
    tmp->left=tmp->right=NULL;
    *tptr=tmp;
    return;
  }
  if (key < tmp->key) {
    InsertNode(&tmp->left, key);
  } else if (key> tmp->key ){
    InsertNode(&tmp->right, key);
  }
}

void DisplayTree(node *t)
{
  if (t != NULL) {
    DisplayTree(t->left);
    printf("%d  ", t->key);
    DisplayTree(t->right);
  }
}

void min_max(node *t)
{
    while (t->left != NULL)
        t = t->left;
    printf("\nMinimum value  = %d\n", t->key);
    
}

int k_smallest_element(node *t, int k)
{
    int ret = -1;
 
    if( t )
    {
        
        node *pTraverse = t;
 
        
        while(pTraverse)
        {
            if( (pTraverse->count + 1) == k )
            {
                ret = pTraverse->key;
                break;
            }
            else if( k > pTraverse->count )
            {
                
                k = k - (pTraverse->count + 1);
                pTraverse = pTraverse->right;
            }
            else
            {
               
                pTraverse = pTraverse->left;
            }
        }
    }
 
    return ret;
}

int main(){
	int i, n, num, k, u; 
	node *tt1, **tt2;
	
	tt1 = NULL;
  	tt2 = &tt1;
	
    num = 1;
 
    printf("Enter the set of numbers for the tree(enter 0 to exit)\n"); 
    while (1) 
    {     
        scanf("%d",  &num); 
        if (num == 0) 
            break; 
        
        InsertNode(tt2, num);
    }
    printf("Tree Displayed in inorder: \n");
    DisplayTree(tt1);
    min_max(tt1);
    
    printf("Enter k: ");
    scanf("%d", &u);
    
    printf("Result for %dth smallest is %d",
                 u, k_smallest_element(tt1, u));
    
    
	
}


