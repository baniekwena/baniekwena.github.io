<?php
		session_start();
												$mydb = mysqli_connect('localhost', 'id1212735_p40501', 'anie6508', 'id1212735_patientportal')or die ('I cannot connect to the database because: ' . mysqli_error());

												$FirstName = $_POST['firstName'];
												$FirstName = stripcslashes($FirstName);
												$FirstName = mysqli_real_escape_string($mydb, $FirstName);
												$LastName = $_POST['lastName'];
												$LastName = stripcslashes($LastName);
												$LastName = mysqli_real_escape_string($mydb, $LastName);
												$UserName = $_POST['username'];
												$UserName = stripcslashes($UserName);
												$UserName = mysqli_real_escape_string($mydb, $UserName);
												$Password = $_POST['password'];
												$Password = stripcslashes($Password);
												$Password = mysqli_real_escape_string($mydb, $Password);
												$Email = $_POST['email'];
												$Email = stripcslashes($Email);
												$Email = mysqli_real_escape_string($mydb, $Email);
												$Address = $_POST['address'];
												$Address = stripcslashes($Address);
												$Address = mysqli_real_escape_string($mydb, $Address);
												$City = $_POST['city'];
												$City = stripcslashes($City);
												$City = mysqli_real_escape_string($mydb, $City);
												$ZipCode = $_POST['zipCode'];
												$ZipCode = stripcslashes($ZipCode);
												$ZipCode = mysqli_real_escape_string($mydb, $ZipCode);
												$Gender = $_POST['gender'];
												$Gender = stripcslashes($Gender);
												$Gender = mysqli_real_escape_string($mydb, $Gender);
												$Birthday = $_POST['birthday'];
												$Birthday = stripcslashes($Birthday);
												$Birthday = mysqli_real_escape_string($mydb, $Birthday);
												$Phone = $_POST['phone'];
												$Phone = stripcslashes($Phone);
												$Phone = mysqli_real_escape_string($mydb, $Phone);
												$Favcolor = $_POST['favcolor'];
												$Favcolor = stripcslashes($Favcolor);
												$Favcolor = mysqli_real_escape_string($mydb, $Favcolor);
												
												
												$id = $_SESSION['pid'];
											
												//$url = 'admin_add_patient_redo.html';
												//if (!preg_match("/^(?=[^A-Z]*[A-Z])(?=[^a-z]*[a-z])(?=[$&+,:;=?@#|'<>.^*()%!-])(?=\D*\d).{8,12}$/", $Password)){
												 // header("Location = $url");
												 // exit();
												//}

												if (!$mydb) {
													die("Connection failed: " . mysqli_connect_error());
												}

												if($FirstName!=''){
													$sql = "UPDATE patients SET firstName = '$FirstName' WHERE id = '$id'"; 
													if (mysqli_query($mydb, $sql)) {
														echo "First name updated successfully";
													} else {
															echo "Error: " . $sql . "<br>" . mysqli_error($mydb);
														}
												}
												
												if($LastName!=''){
													$sql = "UPDATE patients SET lastName = '$LastName' WHERE id = '$id'"; 
													if (mysqli_query($mydb, $sql)) {
														echo "Last name updated successfully";
													} else {
									}
																			echo "Error: " . $sql . "<br>" . mysqli_error($mydb);
													}
												
												if($UserName!=''){
													$sql = "UPDATE patients SET username = '$UserName' WHERE id = '$id'"; 
													if (mysqli_query($mydb, $sql)) {
														echo "username updated successfully";
													} else {
															echo "Error: " . $sql . "<br>" . mysqli_error($mydb);
														}
												}
												
												if($Password!=''){
													$sql = "UPDATE patients SET password = '$Password' WHERE id = '$id'"; 
													if (mysqli_query($mydb, $sql)) {
														echo "Password updated successfully";
													} else {
															echo "Error: " . $sql . "<br>" . mysqli_error($mydb);
														}
												}
												
												if($ZipCode!=''){
													$sql = "UPDATE patients SET zipCode = '$ZipCode' WHERE id = '$id'"; 
													if (mysqli_query($mydb, $sql)) {
														echo "Zip Code updated successfully";
													} else {
															echo "Error: " . $sql . "<br>" . mysqli_error($mydb);
														}
												}
												
												if($Favcolor!=''){
													$sql = "UPDATE patients SET favorite_color = '$Favcolor' WHERE id = '$id'"; 
													if (mysqli_query($mydb, $sql)) {
														echo "favorite color updated successfully";
													} else {
															echo "Error: " . $sql . "<br>" . mysqli_error($mydb);
														}
												}
												if($Email!=''){
													$sql = "UPDATE patients SET email = '$Email' WHERE id = '$id'"; 
													if (mysqli_query($mydb, $sql)) {
														echo "Email updated successfully";
													} else {
															echo "Error: " . $sql . "<br>" . mysqli_error($mydb);
														}
												}
												if($Address!=''){
													$sql = "UPDATE patients SET streetAddress = '$Address' WHERE id = '$id'"; 
													if (mysqli_query($mydb, $sql)) {
														echo "Street Address updated successfully";
													} else {
															echo "Error: " . $sql . "<br>" . mysqli_error($mydb);
														}
												}
												if($City!=''){
													$sql = "UPDATE patients SET city = '$City' WHERE id = '$id'"; 
													if (mysqli_query($mydb, $sql)) {
														echo "City updated successfully";
													} else {
															echo "Error: " . $sql . "<br>" . mysqli_error($mydb);
														}
												}
												if($Birthday!=''){
													$sql = "UPDATE patients SET birthday = '$Birthday' WHERE id = '$id'"; 
													if (mysqli_query($mydb, $sql)) {
														echo "Birthday updated successfully";
													} else {
															echo "Error: " . $sql . "<br>" . mysqli_error($mydb);
														}
												}
												if($Phone!=''){
													$sql = "UPDATE patients SET phone = '$Phone' WHERE id = '$id'"; 
													if (mysqli_query($mydb, $sql)) {
														echo "phone updated successfully";
													} else {
															echo "Error: " . $sql . "<br>" . mysqli_error($mydb);
														}
												}
												
												$url = "index2.php";
												session_destroy();
												header ("Location: $url");
												


?>