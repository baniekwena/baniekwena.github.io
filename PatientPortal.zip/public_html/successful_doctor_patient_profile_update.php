<?php
												session_start();
												
												$mydb = mysqli_connect('localhost', 'id1212735_p40501', 'anie6508', 'id1212735_patientportal')or die ('I cannot connect to the database because: ' . mysqli_error());

												$Procedure = $_POST['procedure'];
												$Procedure = stripcslashes($Procedure);
												$Procedure = mysqli_real_escape_string($mydb, $Procedure);
												$Month = $_POST['month'];
												$Month = stripcslashes($Month);
												$Month = mysqli_real_escape_string($mydb, $Month);
												$Year = $_POST['year'];
												$Year = stripcslashes($Year);
												$Year = mysqli_real_escape_string($mydb, $Year);
												$Bloodtype = $_POST['bloodtype'];
												$Bloodtype = stripcslashes($Bloodtype);
												$Bloodtype = mysqli_real_escape_string($mydb, $Bloodtype);
												$Allergies = $_POST['allergies'];
												$Allergies = stripcslashes($Allergies);
												$Allergies = mysqli_real_escape_string($mydb, $Allergies);
												$Medt = $_POST['medicationsTaking'];
												$Medt = stripcslashes($Medt);
												$Medt = mysqli_real_escape_string($mydb, $Medt);
												$Height = $_POST['height'];
												$Height = stripcslashes($Height);
												$Height = mysqli_real_escape_string($mydb, $Height);
												$Weight = $_POST['weight'];
												$Weight = stripcslashes($Weight);
												$Weight = mysqli_real_escape_string($mydb, $Weight);
												$BP = $_POST['BP'];
												$BP = stripcslashes($BP);
												$BP = mysqli_real_escape_string($mydb, $BP);
												$Temp = $_POST['temp'];
												$Temp = stripcslashes($Temp);
												$Temp = mysqli_real_escape_string($mydb, $Temp);
												$Test = $_POST['test'];
												$Test = stripcslashes($Test);
												$Test = mysqli_real_escape_string($mydb, $Test);
												$Results = $_POST['results'];
												$Results = stripcslashes($Results);
												$Results = mysqli_real_escape_string($mydb, $Results);
												$Med = $_POST['medications'];
												$Med = stripcslashes($Med);
												$Med = mysqli_real_escape_string($mydb, $Med);
												$Dosage = $_POST['dosage'];
												$Dosage = stripcslashes($Dosage);
												$Dosage = mysqli_real_escape_string($mydb, $Dosage);
												$SpI = $_POST['spInstructions'];
												$SpI = stripcslashes($SpI);
												$SpI = mysqli_real_escape_string($mydb, $SpI);
												$TO = $_POST['TestOrder'];
												$TO = stripcslashes($TO);
												$TO = mysqli_real_escape_string($mydb, $TO);
												
												$id = $_SESSION['pid'];
											
												//$url = 'admin_add_patient_redo.html';
												//if (!preg_match("/^(?=[^A-Z]*[A-Z])(?=[^a-z]*[a-z])(?=[$&+,:;=?@#|'<>.^*()%!-])(?=\D*\d).{8,12}$/", $Password)){
												 // header("Location = $url");
												 // exit();
												//}

												if (!$mydb) {
													die("Connection failed: " . mysqli_connect_error());
												}

												if($Procedure!=''){
													$sql = "UPDATE patients SET reason = '$Procedure' WHERE id = '$id'"; 
													if (mysqli_query($mydb, $sql)) {
														echo "First name updated successfully";
													} else {
															echo "Error: " . $sql . "<br>" . mysqli_error($mydb);
														}
												}
												
												if($Month!=''){
													$sql = "UPDATE patients SET month = '$Month' WHERE id = '$id'"; 
													if (mysqli_query($mydb, $sql)) {
														echo "Last name updated successfully";
													} else {
									}
																			echo "Error: " . $sql . "<br>" . mysqli_error($mydb);
													}
												
												if($Year!=''){
													$sql = "UPDATE patients SET YEAR = '$Year' WHERE id = '$id'"; 
													if (mysqli_query($mydb, $sql)) {
														echo "username updated successfully";
													} else {
															echo "Error: " . $sql . "<br>" . mysqli_error($mydb);
														}
												}
												
												if($Bloodtype!=''){
													$sql = "UPDATE patients SET bloodtype = '$Bloodtype' WHERE id = '$id'"; 
													if (mysqli_query($mydb, $sql)) {
														echo "Password updated successfully";
													} else {
															echo "Error: " . $sql . "<br>" . mysqli_error($mydb);
														}
												}
												
												if($Allergies!=''){
													$sql = "UPDATE patients SET allergies = '$Allergies' WHERE id = '$id'"; 
													if (mysqli_query($mydb, $sql)) {
														echo "Zip Code updated successfully";
													} else {
															echo "Error: " . $sql . "<br>" . mysqli_error($mydb);
														}
												}
												
												if($Medt!=''){
													$sql = "UPDATE patients SET medications = '$Medt' WHERE id = '$id'"; 
													if (mysqli_query($mydb, $sql)) {
														echo "favorite color updated successfully";
													} else {
															echo "Error: " . $sql . "<br>" . mysqli_error($mydb);
														}
												}
												if($Height!=''){
													$sql = "UPDATE patients SET height = '$Height' WHERE id = '$id'"; 
													if (mysqli_query($mydb, $sql)) {
														echo "Email updated successfully";
													} else {
															echo "Error: " . $sql . "<br>" . mysqli_error($mydb);
														}
												}
												if($Weight!=''){
													$sql = "UPDATE patients SET weight = '$Weight' WHERE id = '$id'"; 
													if (mysqli_query($mydb, $sql)) {
														echo "Street Address updated successfully";
													} else {
															echo "Error: " . $sql . "<br>" . mysqli_error($mydb);
														}
												}
												if($BP!=''){
													$sql = "UPDATE patients SET BP = '$BP' WHERE id = '$id'"; 
													if (mysqli_query($mydb, $sql)) {
														echo "City updated successfully";
													} else {
															echo "Error: " . $sql . "<br>" . mysqli_error($mydb);
														}
												}
												if($Temp!=''){
													$sql = "UPDATE patients SET temp = '$Temp' WHERE id = '$id'"; 
													if (mysqli_query($mydb, $sql)) {
														echo "Birthday updated successfully";
													} else {
															echo "Error: " . $sql . "<br>" . mysqli_error($mydb);
														}
												}
												if($Test!=''){
													$sql = "UPDATE patients SET test = '$Test' WHERE id = '$id'"; 
													if (mysqli_query($mydb, $sql)) {
														echo "phone updated successfully";
													} else {
															echo "Error: " . $sql . "<br>" . mysqli_error($mydb);
														}
												}
												if($Results!=''){
													$sql = "UPDATE patients SET result = '$Results' WHERE id = '$id'"; 
													if (mysqli_query($mydb, $sql)) {
														echo "phone updated successfully";
													} else {
															echo "Error: " . $sql . "<br>" . mysqli_error($mydb);
														}
												}
												
												if($Med!=''){
													$sql = "UPDATE patients SET med_name = '$Med' WHERE id = '$id'"; 
													if (mysqli_query($mydb, $sql)) {
														echo "phone updated successfully";
													} else {
															echo "Error: " . $sql . "<br>" . mysqli_error($mydb);
														}
														
												if($Dosage!=''){
													$sql = "UPDATE patients SET dosage = '$Dosage' WHERE id = '$id'"; 
													if (mysqli_query($mydb, $sql)) {
														echo "phone updated successfully";
													} else {
															echo "Error: " . $sql . "<br>" . mysqli_error($mydb);
														}
												}
												if($SpI!=''){
													$sql = "UPDATE patients SET special_instrutions = '$SpI' WHERE id = '$id'"; 
													if (mysqli_query($mydb, $sql)) {
														echo "phone updated successfully";
													} else {
															echo "Error: " . $sql . "<br>" . mysqli_error($mydb);
														}
												}
												if($TO!=''){
													$sql = "UPDATE patients SET testorders = '$TO WHERE id = '$id'"; 
													if (mysqli_query($mydb, $sql)) {
														echo "phone updated successfully";
													} else {
															echo "Error: " . $sql . "<br>" . mysqli_error($mydb);
														}
												}
												}
												
												$url = "index2.php";
												session_destroy();
												header ("Location: $url");
												


?>