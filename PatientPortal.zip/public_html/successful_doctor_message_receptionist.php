<!DOCTYPE HTML>
<!--
	Editorial by HTML5 UP
	html5up.net | @ajlkn
	Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)
-->
<?php

	session_start();

?>
<html>
	<head>
		<title>Doctor Landing Page</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<!--[if lte IE 8]><script src="assets/js/ie/html5shiv.js"></script><![endif]-->
		<link rel="stylesheet" href="assets/css/main.css" />
		<!--[if lte IE 9]><link rel="stylesheet" href="assets/css/ie9.css" /><![endif]-->
		<!--[if lte IE 8]><link rel="stylesheet" href="assets/css/ie8.css" /><![endif]-->
	</head>
	<body>

		<!-- Wrapper -->
			<div id="wrapper">

				<!-- Main -->
					<div id="main">
						<div class="inner">

							<!-- Header -->
								<header id="header">
									<a href="#" class="logo"><strong>Patient Portal</a>
								</header>

							<!-- Banner -->
								<section id="banner">
									<div class="content">
										<?php
												date_default_timezone_set('America/Chicago');
		
												$mydb = mysqli_connect('localhost', 'id1212735_p40501', 'anie6508', 'id1212735_patientportal')or die ('I cannot connect to the database because: ' . mysqli_error());

												$Message = $_POST['message'];
												$Message = stripcslashes($Message);
												$Message = mysqli_real_escape_string($mydb, $Message);
												
												$Username = $_SESSION['username'];
												
												$sql = "UPDATE Receptionist SET from_message = 'Doctor: $Username' WHERE id = '1'";
												mysqli_query($mydb, $sql);
												
												if($Message!=''){
													$sql = "UPDATE Receptionist SET message = '$Message' WHERE id = '1'";
													mysqli_query($mydb, $sql);
													print '<h1>Message has been sent to a Receptionist ' .date('l jS \of F Y h:i:s A'). '<h1>';
												} else{
													echo 'Error!';
													
												}
												
												?>
									</div>
								</section>

							<!-- Section -->

							<!-- Section -->
								

						</div>
					</div>

				<!-- Sidebar -->
					<div id="sidebar">
						<div class="inner">

							<!-- Search -->
								
									<form method="GET" action="doctor_search_results.php">
										<input type="text" name="query" id="query" placeholder="Search Patients" />
										<input type = "submit">
									</form>
								

							<!-- Menu -->
								<nav id="menu">
									<header class="major">
										<h2>Menu</h2>
									</header>
									<ul>
										<li><a href="doctor_view_patient_info.php">View/Update Patient Personal Information</a></li>
										<li><a href="doctor_view_patient_medical_history.php">View/Update Medical History</a></li>
										<li><a href="doctor_view_patient_vitals.php">Enter/View Patient Vitals</a></li>
										<li><a href="doctor_view_patient_medical_info.php">Enter/View Medical Information</a></li>
										<li><a href="doctor_enter_patient_results.php">Enter/Update Prescriptions</a></li>
										<li><a href="doctor_view_OT.php">Enter/Update Ordered Lab Tests</a></li>
										<li><a href="doctor_view_results.php">Enter Test Results</a></li>
										<li><a href="https://patientportal.secure.simplybook.me/v2/" target = "_blank">Manage Appointments</a></li>
										<li><a href="doctor_view_message.php">View Messages</a></li>
										<li>
							                            <span class="opener">Send Message To...</span>
											<ul>
											    <li><a href="doctor_message_Receptionist.php">Receptionist</a></li>
											</ul>
										</li>
										<li><a href="http://www.webmd.com/search/default.aspx?invalid=1" target = "_blank">WebMD Search</a></li>
										<li><a href="log_out.php">Log Out</a></li>
									</ul>
								</nav>

							<!-- Section -->
								

							<!-- Section -->

							<!-- Footer -->
								<footer id="footer">
									<p class="copyright">&copy; "Baby Steps" 2017 Niu Software Engineering class. All rights reserved. Design: <a href="https://html5up.net">HTML5 UP</a>.</p>
								</footer>

						</div>
					</div>

			</div>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/util.js"></script>
			<!--[if lte IE 8]><script src="assets/js/ie/respond.min.js"></script><![endif]-->
			<script src="assets/js/main.js"></script>

	</body>
</html>