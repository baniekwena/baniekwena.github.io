<?php
	$mydb = mysqli_connect('localhost', 'id1212735_p40501', 'anie6508', 'id1212735_patientportal')or die ('I cannot connect to the database because: ' . mysqli_error());
	
	$FirstName = $_POST['firstName'];
	$FirstName = stripcslashes($FirstName);
	$FirstName = mysqli_real_escape_string($mydb, $FirstName);
	$LastName = $_POST['lastName'];
	$LastName = stripcslashes($LastName);
	$LastName = mysqli_real_escape_string($mydb, $LastName);
	$UserName = $_POST['username'];
	$UserName = stripcslashes($UserName);
	$UserName = mysqli_real_escape_string($mydb, $UserName);
	$Password = $_POST['password'];
	$Password = stripcslashes($Password);
	$Password = mysqli_real_escape_string($mydb, $Password);
	
	if (!$mydb) {
		die("Connection failed: " . mysqli_connect_error());
	}
	
					$sql = "INSERT INTO patients (username, password, firstName, lastName)
					VALUES ('$UserName', '$Password', '$FirstName', '$LastName')";

					if (mysqli_query($mydb, $sql)) {
					echo "New record created successfully";
					} else {
					echo "Error: " . $sql . "<br>" . mysqli_error($mydb);
					}
					
	
	mysqli_close($mydb);


?>