<!DOCTYPE HTML>
<!--
	Editorial by HTML5 UP
	html5up.net | @ajlkn
	Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)
-->
<?php

	session_start();

?>
<html>
	<head>
		<title>Patient Information</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<!--[if lte IE 8]><script src="assets/js/ie/html5shiv.js"></script><![endif]-->
		<link rel="stylesheet" href="assets/css/main.css" />
		<!--[if lte IE 9]><link rel="stylesheet" href="assets/css/ie9.css" /><![endif]-->
		<!--[if lte IE 8]><link rel="stylesheet" href="assets/css/ie8.css" /><![endif]-->
	</head>
	<body>

		<!-- Wrapper -->
			<div id="wrapper">

				<!-- Main -->
					<div id="main">
						<div class="inner">

							<!-- Header -->
								<header id="header">
									<a href="#" class="logo"><strong>Patient Portal</a>
								</header>

							<!-- Banner -->
								<section id="banner">
									<div class="content">
										<header>
											<h1>View/Update Personal Information</h1>
											<p>To edit specific personal information, start typing on the corresponding form field located on the bottom half of the page and click "submit"</p>
										</header>
										<?php
											print "<h1>" .$_SESSION['firstname'] . " " .$_SESSION['lastname']. "'s Personal Information On File</h1>";
											print '<h3>Address: ' .$_SESSION['streetAddress'] . " " .$_SESSION['city'] . " " .$_SESSION['zipCode']. '</h3>';
											print '<h3>Phone Number: ' .$_SESSION['phone'] . '</h3>';
											print '<h3>Email: ' .$_SESSION['email'] .'</h3>';
											print '<h3>Gender: ' .$_SESSION['gender'] . '</h3>';
											print '<h3>Birthday: ' .$_SESSION['birthday'] .'</h3>';
											print '<h3>Username: ' .$_SESSION['username'] .'</h3>';
											print '<h3>Password: ' .$_SESSION['password'] .'</h3>';
											print '<h3>Favorite Color: ' .$_SESSION['favcolor'] .'</h3>';
										?>
										<br>
										<br>
										<br>
										<br>
										<h1>Edit...</h1>
										<form method="post" action="successful_patient_update.php">
														<div class="row uniform">
															<div class="6u$ 12u$(xsmall)">
																<input type="text" name="password" id="password" value="" placeholder="Password" />
															</div>
															<div class="6u$ 12u$(xsmall)">
																<input type="text" name="email" id="email" value="" placeholder="Email" />
															</div>
															<div class="6u$ 12u$(xsmall)">
																<input type="text" name="address" id="address" value="" placeholder="Address" />
															</div>
															<div class="6u$ 12u$(xsmall)">
																<input type="text" name="city" id="city" value="" placeholder="City" />
															</div>
															<div class="6u$ 12u$(xsmall)">
																<input type="text" name="zipCode" id="zipCode" value="" placeholder="Zip Code" />
															</div>
															<div class="6u$ 12u$(xsmall)">
																<input type="text" name="phone" id="phone" value="" placeholder="Phone Number" />
															</div>
															<div class="6u$ 12u$(xsmall)">
																<input type="text" name="favcolor" id="favcolor" value="" placeholder="Favorite Color" />
															</div>
															<!-- Break -->
															<div class="12u$">
																<ul class="actions">
																	<li><input type="submit" value="Submit" class="special" /></li>
																</ul>
															</div>
														</div>
													</form>
												</div>
								</section>

							<!-- Section -->

							<!-- Section -->


						</div>
					</div>

				<!-- Sidebar -->
					<div id="sidebar">
						<div class="inner">

							<!-- Menu -->
								<nav id="menu">
									<header class="major">
										<h2>Menu</h2>
									</header>
									<ul>
										<li><a href="request_an_appointment.html">Request an Appointment</a></li>
										<li><a href="medical_history.php">View Medical History</a></li>
										<li><a href="update_personal_information.php">View/Update Personal Information</a></li>
										<li><a href="view_profile.php">View Profile</a></li>
										<li><a href="pay_bill.php">View/Pay Bill</a></li>
										<li><a href="patient_view_message.php">View Messages</a></li>
										<li>
											<span class="opener">Send Message To...</span>
											<ul>
												<li><a href="patient_message_receptionist.php">Receptionist</a></li>
											</ul>
										</li>
										<li><a href="http://www.webmd.com/search/default.aspx?invalid=1" target = "_blank">WebMD Search</a></li>
										<li><a href="log_out.php">Log Out</a></li>
									</ul>
								</nav>

							<!-- Section -->


							<!-- Section -->

							<!-- Footer -->
								<footer id="footer">
									<p class="copyright">&copy; "Baby Steps" 2017 Niu Software Engineering class. All rights reserved. Design: <a href="https://html5up.net">HTML5 UP</a>.</p>
								</footer>

						</div>
					</div>

			</div>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/util.js"></script>
			<!--[if lte IE 8]><script src="assets/js/ie/respond.min.js"></script><![endif]-->
			<script src="assets/js/main.js"></script>

	</body>
</html>