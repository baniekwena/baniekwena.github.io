<?php

	$query = $_GET['query'];
	$db = mysqli_connect('localhost', 'id1212735_p40501', 'anie6508', 'id1212735_patientportal')or die ('I cannot connect to the database because: ' . mysql_error());
	$query = stripcslashes($query);
	$query = mysqli_real_escape_string($db,$query)or die ('I cannot connect to the database because: ' . mysql_error());
	
	
	$mydb=mysqli_select_db("id1212735_patientportal");

	//-query the database table
	$sql="SELECT * FROM patients WHERE firstName LIKE '%" . $query . "%' OR lastName LIKE '%" . $query ."%'";

	//-run the query against the mysql query function
	$result=mysqli_query($sql) or die("could not search");

	//-count results

	$numrows=mysqli_num_rows($result);
		if($numrows == 0){
			echo "no patients were found";
		}
	else{
	

	echo "<p>" .$numrows . " results found for " . stripslashes($query) . "</p>"; 

	//-create while loop and loop through result set
	while($row=mysqli_fetch_array($result)){

	$firstName =$row['firstName'];
	$lastName=$row['lastName'];
	$ID=$row['id'];
		
	//-display the result of the array

	echo "<ul>\n"; 
	echo "<li>" . "<a href=\"search.php?id=$ID\">"  .$firstName . " " . $lastName . "</a></li>\n";
	echo "</ul>";
	}

	}

?>
