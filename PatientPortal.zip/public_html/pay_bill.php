<!DOCTYPE HTML>
<!--
	Editorial by HTML5 UP
	html5up.net | @ajlkn
	Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)
-->
<?php

	session_start();

?>
<html>
	<head>
		<title>View/Pay Bill</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<!--[if lte IE 8]><script src="assets/js/ie/html5shiv.js"></script><![endif]-->
		<link rel="stylesheet" href="assets/css/main.css" />
		<!--[if lte IE 9]><link rel="stylesheet" href="assets/css/ie9.css" /><![endif]-->
		<!--[if lte IE 8]><link rel="stylesheet" href="assets/css/ie8.css" /><![endif]-->
	</head>
	<body>

		<!-- Wrapper -->
			<div id="wrapper">

				<!-- Main -->
					<div id="main">
						<div class="inner">

							<!-- Header -->
								<header id="header">
									<a href="#" class="logo"><strong>Patient Portal</a>
								</header>

							<!-- Banner -->
								<section id="banner">
									<div class="content">
										<header>
											<h1>View/Pay Bill</h1>
											<p>This is just a demo, please refrain from putting actual card information</p>
										</header>
										<?php
											print "<h1>Total Balance: $" .$_SESSION['balance'] . "</h1>";
											print "<h1>Balance Due After Insurance: $" .$_SESSION['balance'] . "</h1>";
										?>
										<br>
										<br>
										<br>
										<br>
										<h1>Pay...</h1>
										<form method="post" action="successful_payment.php">
														<div class="row uniform">
															<div class="6u$ 12u$(xsmall)">
																<label>Full Name on Card</label>
																<input type="text" name="" id="password" value="" />
															</div>
															<div class="6u$ 12u$(xsmall)">
																<label>Card Number</label>
																<input type="text" name="" id="email" value=""/>
															</div>
															<div class="6u$ 12u$(xsmall)">
																<label>Payment Date</label>
																<input type="text" name="" id="address" value="" />
															</div>
															<div class="6u$ 12u$(xsmall)">
																<label>Amount</label>
																<input type="text" name="amount" id="" value="" />
															</div>
															<div class="6u$ 12u$(xsmall)">
																<label>Address</label>
																<input type="text" name="zipCode" id="zipCode" value="" />
															</div>
															<div class="6u$ 12u$(xsmall)">
															<label>Zip Code</label>
																<input type="text" name="" id="" value="" />
															</div>
															<div class="6u$ 12u$(xsmall)">
															<label>CSN</label>
																<input type="text" name="" id="" value="" />
															</div>
															<!-- Break -->
															<div class="12u$">
																<ul class="actions">
																	<li><input type="submit" value="Pay" class="special" /></li>
																</ul>
															</div>
														</div>
													</form>

									</div>
								</section>

							<!-- Section -->

							<!-- Section -->


						</div>
					</div>

				<!-- Sidebar -->
					<div id="sidebar">
						<div class="inner">

							<!-- Menu -->
								<nav id="menu">
									<header class="major">
										<h2>Menu</h2>
									</header>
									<ul>
										<li><a href="request_an_appointment.html">Request an Appointment</a></li>
										<li><a href="medical_history.php">View Medical History</a></li>
										<li><a href="update_personal_information.php">View/Update Personal Information</a></li>
										<li><a href="view_profile.php">View Profile</a></li>
										<li><a href="pay_bill.php">View/Pay Bill</a></li>
										<li><a href="patient_view_message.php">View Messages</a></li>
										<li>
										    <span class="opener">Send Message To...</span>
										        <ul>
											    <li><a href="patient_message_receptionist.php">Receptionist</a></li>
											</ul>
										</li>
										<li><a href="http://www.webmd.com/search/default.aspx?invalid=1" target = "_blank">WebMD Search</a></li>
										<li><a href="log_out.php">Log Out</a></li>
									</ul>
								</nav>

							<!-- Section -->


							<!-- Section -->

							<!-- Footer -->
								<footer id="footer">
									<p class="copyright">&copy; "Baby Steps" 2017 Niu Software Engineering class. All rights reserved. Design: <a href="https://html5up.net">HTML5 UP</a>.</p>
								</footer>

						</div>
					</div>

			</div>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/util.js"></script>
			<!--[if lte IE 8]><script src="assets/js/ie/respond.min.js"></script><![endif]-->
			<script src="assets/js/main.js"></script>

	</body>
</html>