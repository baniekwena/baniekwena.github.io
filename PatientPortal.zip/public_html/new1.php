<!DOCTYPE html>
<html>
<head>
	<title>Patient Login Page</title>
	<link rel="stylesheet" type="text/css" href="">
</head>
<body>
	<h1>Welcome PATIENT
<?php
	
	

?>
</h1>
	
	
</body>
</html>