<!DOCTYPE html>
<html >
<head>
  <meta charset="UTF-8">
  <title>Patient Portal</title>
  
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">

  
      <style>
      /* NOTE: The styles were added inline because Prefixfree needs access to your styles and they must be inlined if they are on local disk! */
@import url(http://fonts.googleapis.com/css?family=Open+Sans);
.btn { display: inline-block; *display: inline; *zoom: 1; padding: 4px 10px 4px; margin-bottom: 0; font-size: 13px; line-height: 18px; color: #333333; text-align: center;text-shadow: 0 1px 1px rgba(255, 255, 255, 0.75); vertical-align: middle; background-color: #f5f5f5; background-image: -moz-linear-gradient(top, #ffffff, #e6e6e6); background-image: -ms-linear-gradient(top, #ffffff, #e6e6e6); background-image: -webkit-gradient(linear, 0 0, 0 100%, from(#ffffff), to(#e6e6e6)); background-image: -webkit-linear-gradient(top, #ffffff, #e6e6e6); background-image: -o-linear-gradient(top, #ffffff, #e6e6e6); background-image: linear-gradient(top, #ffffff, #e6e6e6); background-repeat: repeat-x; filter: progid:dximagetransform.microsoft.gradient(startColorstr=#ffffff, endColorstr=#e6e6e6, GradientType=0); border-color: #e6e6e6 #e6e6e6 #e6e6e6; border-color: rgba(0, 0, 0, 0.1) rgba(0, 0, 0, 0.1) rgba(0, 0, 0, 0.25); border: 1px solid #e6e6e6; -webkit-border-radius: 4px; -moz-border-radius: 4px; border-radius: 4px; -webkit-box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.2), 0 1px 2px rgba(0, 0, 0, 0.05); -moz-box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.2), 0 1px 2px rgba(0, 0, 0, 0.05); box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.2), 0 1px 2px rgba(0, 0, 0, 0.05); cursor: pointer; *margin-left: .3em; }
.btn:hover, .btn:active, .btn.active, .btn.disabled, .btn[disabled] { background-color: #e6e6e6; }
.btn-large { padding: 9px 14px; font-size: 15px; line-height: normal; -webkit-border-radius: 5px; -moz-border-radius: 5px; border-radius: 5px; }
.btn:hover { color: #333333; text-decoration: none; background-color: #e6e6e6; background-position: 0 -15px; -webkit-transition: background-position 0.1s linear; -moz-transition: background-position 0.1s linear; -ms-transition: background-position 0.1s linear; -o-transition: background-position 0.1s linear; transition: background-position 0.1s linear; }
.btn-primary, .btn-primary:hover { text-shadow: 0 -1px 0 rgba(0, 0, 0, 0.25); color: #ffffff; }
.btn-primary.active { color: rgba(255, 255, 255, 0.75); }
.btn-primary { background-color: #4a77d4; background-image: -moz-linear-gradient(top, #6eb6de, #4a77d4); background-image: -ms-linear-gradient(top, #6eb6de, #4a77d4); background-image: -webkit-gradient(linear, 0 0, 0 100%, from(#6eb6de), to(#4a77d4)); background-image: -webkit-linear-gradient(top, #6eb6de, #4a77d4); background-image: -o-linear-gradient(top, #6eb6de, #4a77d4); background-image: linear-gradient(top, #6eb6de, #4a77d4); background-repeat: repeat-x; filter: progid:dximagetransform.microsoft.gradient(startColorstr=#6eb6de, endColorstr=#4a77d4, GradientType=0);  border: 1px solid #3762bc; text-shadow: 1px 1px 1px rgba(0,0,0,0.4); box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.2), 0 1px 2px rgba(0, 0, 0, 0.5); }
.btn-primary:hover, .btn-primary:active, .btn-primary.active, .btn-primary.disabled, .btn-primary[disabled] { filter: none; background-color: #4a77d4; }
.btn-block { width: 100%; display:block; }

* { -webkit-box-sizing:border-box; -moz-box-sizing:border-box; -ms-box-sizing:border-box; -o-box-sizing:border-box; box-sizing:border-box; }

html { width: 100%; height:100%; overflow:hidden; }

body { 
	width: 100%;
	height:100%;
	font-family: 'Open Sans', sans-serif;
	background: white;

}
.login { 
	position: absolute;
	top: 50%;
	left: 50%;
	margin: -150px 0 0 -150px;
	width:300px;
	height:300px;
}
.login h1 { color: black; text-shadow: letter-spacing:1px; text-align:center; }
.login h2 { color: red; letter-spacing:1px; text-align:center; }
.login h5 { color: black; text-align:center;}
input { 
	width: 100%; 
	margin-bottom: 10px; 
	background: rgba(0,0,0,0.3);
	border: none;
	outline: none;
	padding: 10px;
	font-size: 13px;
	color: #fff;
	text-shadow: 1px 1px 1px rgba(0,0,0,0.3);
	border: 1px solid rgba(0,0,0,0.3);
	border-radius: 4px;
	box-shadow: inset 0 -5px 45px rgba(100,100,100,0.2), 0 1px 1px rgba(255,255,255,0.2);
	-webkit-transition: box-shadow .5s ease;
	-moz-transition: box-shadow .5s ease;
	-o-transition: box-shadow .5s ease;
	-ms-transition: box-shadow .5s ease;
	transition: box-shadow .5s ease;
}
input:focus { box-shadow: inset 0 -5px 45px rgba(100,100,100,0.4), 0 1px 1px rgba(255,255,255,0.2); }


    </style>

  <script src="https://cdnjs.cloudflare.com/ajax/libs/prefixfree/1.0.7/prefixfree.min.js"></script>

</head>

<body>




  <div class="login">
  <?php
  
	$dsn = "mysql:host=localhost;dbname=id1212735_patientportal";
	$username = "id1212735_p40501"; 
	$password = "anie6508";
	// Above is my test database information. You'll need to use your own. See Dormilich's tutorial on PDO for more information.
	$options = array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION);

	$pdo = new PDO($dsn, $username, $password, $options);
	$max_time_in_seconds = 30;
	$max_attempts = 3;
	
	

	if(login_attempt_count($max_time_in_seconds, $pdo) <= $max_attempts) {
  
	echo "<h1>Patient Portal</h1>";
	echo "<h2>Username or Password is incorrect, please use credentials given by clinic</h2>";

	echo '
    <form action="process.php" method="POST">
			<p>
				<label>Username:</label>
				<input type="text" id="username" name="username" />
				
				

			</p>
			<p>
				<label>Password:</label>
				<input type="password" id="password" name="password" />
			</p>
			<p>
				<input type="submit" id="btn" value="login" />
			</p>
		</form>
		<h5><a href= "username_retrieval.php"> Forgot Username?</a></h5>
		<h5><a href= "password_retrieval.php"> Forgot Password?</a></h5>	';
	} else {
	echo "I'm sorry, you've made too many attempts to log in too quickly, the Account with the Username you were attempting to log into is not locked, please contact the clinic for futher instructions.<br>";
	// Do not show the login form, since it may be a bot trying to log in.
	}

	function login_attempt_count($seconds, $pdo) {
		try {
			// First we delete old attempts from the table
			$del_old = "DELETE FROM attempts WHERE `when` < ?";
			$oldest = strtotime(date("Y-m-d H:i:s")." - ".$seconds." seconds");
			$oldest = date("Y-m-d H:i:s",$oldest);
			$del_data = array($oldest);
			$remove = $pdo->prepare($del_old);
			$remove->execute($del_data);
		
			// Next we insert this attempt into the table
			$insert = "INSERT INTO attempts (`ip`, `when`) VALUES ( ?, ? )";
			$data = array($_SERVER['REMOTE_ADDR'], date("Y-m-d H:i:s"));
			$input = $pdo->prepare($insert);
			$input->execute($data);
		
			// Finally we count the number of recent attempts from this ip address	
			$count = "SELECT count(*) as number FROM attempts where `ip` = ?";
			$num = $pdo->prepare($count);
			$num->execute(array($_SERVER['REMOTE_ADDR']));
			foreach($num as $attempt) {
				$attempts = $attempt['number'];
			}
			return $attempts;
		} catch (PDOEXCEPTION $e) {
			echo "Error: ".$e;
		}
	}
		
	?>
</div>
  
    <script src="js/index.js"></script>

</body>
</html>