<!DOCTYPE HTML>
<!--
	Editorial by HTML5 UP
	html5up.net | @ajlkn
	Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)
-->

<?php

	session_start();
	
	

?>
<html>
	<head>
		<title>Select Patient Page</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<!--[if lte IE 8]><script src="assets/js/ie/html5shiv.js"></script><![endif]-->
		<link rel="stylesheet" href="assets/css/main.css" />
		<!--[if lte IE 9]><link rel="stylesheet" href="assets/css/ie9.css" /><![endif]-->
		<!--[if lte IE 8]><link rel="stylesheet" href="assets/css/ie8.css" /><![endif]-->
	</head>
	<body>

		<!-- Wrapper -->
			<div id="wrapper">

				<!-- Main -->
					<div id="main">
						<div class="inner">

							<!-- Header -->
								<header id="header">
									<a href="#" class="logo"><strong>Patient Portal</a>
								</header>

							<!-- Banner -->
								<section id="banner">
									<div class="content">
										<?php
		$username = $_POST['username'];
		$db = mysqli_connect('localhost', 'id1212735_p40501', 'anie6508', 'id1212735_patientportal');
		$username = stripcslashes($username);
		$username = mysqli_real_escape_string($db,$username);
		$_SESSION['username'] = $username;
	
		$url = 'nurse.php';
        $url2 = 'doctor.php';
        $url3 = 'patient.php';
        $url4 = 'receptionist.php';
		$url5 = 'admin.php';
		$url7 = 'failed_login_attempt.php';
		$url6 = 'failed_login_attempt2.php';
	
		$result = mysqli_query($db, "select * from patients where username = '$username'");
	
		$row = mysqli_fetch_array($result);
		
		if ($row['username'] == $username && ($row['username'] != '')){
			$results = mysqli_query($db, "select * from patients where username = '$username'");
			$rows = mysqli_fetch_array($results);
			$_SESSION['pid'] = $rows['id'];
			$_SESSION['pusername'] = $rows['username'];
			$_SESSION['pfirstname'] = $rows['firstName'];
			$_SESSION['plastname'] = $rows['lastName'];
			$_SESSION['ppassword'] = $rows['password'];
			$_SESSION['pstreetAddress'] = $rows['streetAddress'];
			$_SESSION['pcity'] = $rows['city'];
			$_SESSION['pzipCode'] = $rows['zipCode'];
			$_SESSION['pgender'] = $rows['gender'];
			$_SESSION['pbirthday'] = $rows['birthday'];
			$_SESSION['pphone'] = $rows['phone'];
			$_SESSION['pemail'] = $rows['email'];
			$_SESSION['pfavcolor'] = $rows['favorite_color'];
			$_SESSION['pbalance'] = $rows['balance'];
			$_SESSION['pmonth'] = $rows['month'];
			$_SESSION['pYEAR'] = $rows['YEAR'];
			$_SESSION['preason'] = $rows['reason'];
			$_SESSION['pbloodtype'] = $rows['bloodtype'];
			$_SESSION['pallergies'] = $rows['allergies'];
			$_SESSION['pmedications'] = $rows['medications'];
			$_SESSION['pheight'] = $rows['height'];
			$_SESSION['pweight'] = $rows['weight'];
			$_SESSION['pBP'] = $rows['BP'];
			$_SESSION['ptemp'] = $rows['temp'];
			$_SESSION['ptest'] = $rows['test'];
			$_SESSION['presult'] = $rows['result'];
			$_SESSION['pmed_name'] = $rows['med_name'];
			$_SESSION['pdosage'] = $rows['dosage'];
			$_SESSION['pspecial_instructions'] = $rows['special_instrutions'];
			$_SESSION['ptestorders'] = $rows['testorders'];
			$_SESSION['plast_date'] = $rows['last_date'];
			$_SESSION['pmessage'] = $rows['message'];
			$_SESSION['pfrom_message'] = $rows['from_message'];
			
			print "<h1>You have Selected Patient ".$_SESSION['pfirstname']." ".$_SESSION['plastname']."</h1>";
		} 
		
?>
									</div>
								</section>

							<!-- Section -->

							<!-- Section -->
								

						</div>
					</div>

				<!-- Sidebar -->
					<div id="sidebar">
						<div class="inner">

							<!-- Search -->
								<section id="search" class="alt">
									<form method="GET" action="doctor_search_results.php">
										<input type="text" name="query" id="query" placeholder="Search Patients" />
										<input type = "submit">
									</form>
								</section>

							<!-- Menu -->
								<nav id="menu">
									<header class="major">
										<h2>Menu</h2>
									</header>
									<ul>
										<li><a href="doctor_view_patient_info.php">View/Update Patient Personal Information</a></li>
										<li><a href="doctor_view_patient_medical_history.php">View/Update Medical History</a></li>
										<li><a href="doctor_view_patient_vitals.php">Enter/View Patient Vitals</a></li>
										<li><a href="doctor_view_patient_medical_info.php">Enter/View Medical Information</a></li>
										<li><a href="doctor_enter_patient_results.php">Enter/Update Prescriptions</a></li>
										<li><a href="doctor_view_OT.php">Enter/Update Ordered Lab Tests</a></li>
										<li><a href="doctor_view_results.php">Enter Test Results</a></li>
										<li><a href="https://patientportal.secure.simplybook.me/v2/" target = "_blank">Manage Appointments</a></li>
										<li><a href="doctor_view_message.php">View Messages</a></li>
										<li>
							                            <span class="opener">Send Message To...</span>
											<ul>
											    <li><a href="doctor_message_Receptionist.php">Receptionist</a></li>
											</ul>
										</li>
										<li><a href="http://www.webmd.com/search/default.aspx?invalid=1" target = "_blank">WebMD Search</a></li>
										<li><a href="log_out.php">Log Out</a></li>
									</ul>
								</nav>

							<!-- Section -->
								

							<!-- Section -->

							<!-- Footer -->
								<footer id="footer">
									<p class="copyright">&copy; "Baby Steps" 2017 Niu Software Engineering class. All rights reserved. Design: <a href="https://html5up.net">HTML5 UP</a>.</p>
								</footer>

						</div>
					</div>

			</div>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/util.js"></script>
			<!--[if lte IE 8]><script src="assets/js/ie/respond.min.js"></script><![endif]-->
			<script src="assets/js/main.js"></script>

	</body>
</html>