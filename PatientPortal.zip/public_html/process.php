<?php
		session_start();
		$username = $_POST['username'];
		$password = $_POST['password'];
		$db = mysqli_connect('localhost', 'id1212735_p40501', 'anie6508', 'id1212735_patientportal');
		$username = stripcslashes($username);
		$password = stripcslashes($password);
		$username = mysqli_real_escape_string($db,$username);
		$password = mysqli_real_escape_string($db,$password);
		$_SESSION['username'] = $username;
	
		$url = 'nurse.php';
        $url2 = 'doctor.php';
        $url3 = 'patient.php';
        $url4 = 'receptionist.php';
		$url5 = 'admin.php';
		$url7 = 'failed_login_attempt.php';
		$url6 = 'failed_login_attempt2.php';
	
		$result = mysqli_query($db, "select * from patients where username = '$username' and password = '$password'");
		$result2 = mysqli_query($db, "select * from doctors where username = '$username' and password = '$password'");
		$result3 = mysqli_query($db, "select * from Nurse where username = '$username' and password = '$password'");
		$result4 = mysqli_query($db, "select * from Receptionist where username = '$username' and password = '$password'");
		$result5 = mysqli_query($db, "select * from Admin where Username = '$username' and Password = '$password'");
	
		$row = mysqli_fetch_array($result);
		$row2 = mysqli_fetch_array($result2);
		$row3 = mysqli_fetch_array($result3);
        $row4 = mysqli_fetch_array($result4);
		$row5 = mysqli_fetch_array($result5);
	
		if($username != '' || $password != ''){
			header("Location: $url6");
		}
		
		if ($row['username'] == $username && $row['password'] == $password && ($row['username'] != '' || $row['password'] != '')){
			$results = mysqli_query($db, "select * from patients where username = '$username'");
			$rows = mysqli_fetch_array($results);
			$_SESSION['id'] = $rows['id'];
			$_SESSION['firstname'] = $rows['firstName'];
			$_SESSION['lastname'] = $rows['lastName'];
			$_SESSION['password'] = $rows['password'];
			$_SESSION['streetAddress'] = $rows['streetAddress'];
			$_SESSION['city'] = $rows['city'];
			$_SESSION['zipCode'] = $rows['zipCode'];
			$_SESSION['gender'] = $rows['gender'];
			$_SESSION['birthday'] = $rows['birthday'];
			$_SESSION['phone'] = $rows['phone'];
			$_SESSION['email'] = $rows['email'];
			$_SESSION['favcolor'] = $rows['favorite_color'];
			$_SESSION['balance'] = $rows['balance'];
			$_SESSION['month'] = $rows['month'];
			$_SESSION['YEAR'] = $rows['YEAR'];
			$_SESSION['reason'] = $rows['reason'];
			$_SESSION['bloodtype'] = $rows['bloodtype'];
			$_SESSION['allergies'] = $rows['allergies'];
			$_SESSION['medications'] = $rows['medications'];
			$_SESSION['height'] = $rows['height'];
			$_SESSION['weight'] = $rows['weight'];
			$_SESSION['BP'] = $rows['BP'];
			$_SESSION['temp'] = $rows['temp'];
			$_SESSION['test'] = $rows['test'];
			$_SESSION['result'] = $rows['result'];
			$_SESSION['med_name'] = $rows['med_name'];
			$_SESSION['dosage'] = $rows['dosage'];
			$_SESSION['special_instructions'] = $rows['special_instructions'];
			$_SESSION['testorders'] = $rows['testorders'];
			$_SESSION['last_date'] = $rows['last_date'];
			$_SESSION['message'] = $rows['message'];
			$_SESSION['from_message'] = $rows['from_message'];
			header( "Location: $url3" );
		} 
	
		if ($row2['username'] == $username && $row2['password'] == $password && ($row2['username'] != '' || $row2['password'] != '')){
			$results = mysqli_query($db, "select * from doctors where username = '$username'");
			$rows = mysqli_fetch_array($results);
			$_SESSION['id'] = $rows['id'];
			$_SESSION['firstname'] = $rows['firstName'];
			$_SESSION['lastname'] = $rows['lastName'];
			$_SESSION['password'] = $rows['password'];
			$_SESSION['email'] = $rows['email'];
			$_SESSION['favcolor'] = $rows['favorite_color'];
			$_SESSION['message'] = $rows['message'];
			$_SESSION['from_message'] = $rows['from_message'];
			$_SESSION['username'] = $rows['username'];
			
			header( "Location: $url2" );
		}
		
		if ($row3['username'] == $username && $row3['password'] == $password && ($row3['username'] != '' || $row3['password'] != '')){
			$results = mysqli_query($db, "select * from Nurse where username = '$username'");
			$rows = mysqli_fetch_array($results);
			$_SESSION['id'] = $rows['id'];
			$_SESSION['firstname'] = $rows['firstname'];
			$_SESSION['lastname'] = $rows['lastname'];
			$_SESSION['password'] = $rows['password'];
			$_SESSION['email'] = $rows['email'];
			$_SESSION['favcolor'] = $rows['favorite_color'];
			$_SESSION['message'] = $rows['message'];
			$_SESSION['from_message'] = $rows['from_message'];
			$_SESSION['username'] = $rows['username'];
			
			header( "Location: $url" );
		} 
		
        if ($row4['username'] == $username && $row4['password'] == $password && ($row4['username'] != '' || $row4['password'] != '')){
			$results = mysqli_query($db, "select * from Receptionist where username = '$username'");
			$rows = mysqli_fetch_array($results);
			$_SESSION['id'] = $rows['id'];
			$_SESSION['firstname'] = $rows['FirstName'];
			$_SESSION['lastname'] = $rows['LastName'];
			$_SESSION['password'] = $rows['password'];
			$_SESSION['email'] = $rows['email'];
			$_SESSION['favcolor'] = $rows['favorite_color'];
			$_SESSION['message'] = $rows['message'];
			$_SESSION['from_message'] = $rows['from_message'];
			$_SESSION['username'] = $rows['username'];
			
			header( "Location: $url4" );
		}
		
		if ($row5['Username'] == $username && $row5['Password'] == $password && ($row5['Username'] != '' || $row5['Password'] !='')){
			$results = mysqli_query($db, "select * from Admin where Username = '$username'");
			$rows = mysqli_fetch_array($results);
			$_SESSION['id'] = $rows['ID'];
			$_SESSION['firstname'] = $rows['Firstname'];
			$_SESSION['lastname'] = $rows['Lastname'];
			$_SESSION['password'] = $rows['Password'];
			$_SESSION['email'] = $rows['Email'];
			$_SESSION['favcolor'] = $rows['favorite_color'];
			$_SESSION['message'] = $rows['message'];
			$_SESSION['from_message'] = $rows['from_message'];
			$_SESSION['username'] = $rows['username'];
			
			header( "Location: $url5" );
		} 
		
		if($username == '' || $password == ''){
			header("Location: $url7");
		}
		
?>
