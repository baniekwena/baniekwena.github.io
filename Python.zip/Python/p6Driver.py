#Imports

import sys
import re
from address import getAddress
from checkAddress import parseAddress, printAddress, Count

if len(sys.argv) < 2:
	print("filename needed as command argument")
	sys.exit(1)

file = open(sys.argv[1], "r")
while True:
	inputLine = file.readline()
	if inputLine == "":
		break
	inputLine = inputLine.rstrip('\n')
	inputLine = inputLine.rstrip('\r')
	token = inputLine.split()
	token2 = token[1:]
	if token[0] == "CUSTOMER":
		print("%-35sStNum Direction  AptNum StType    StName"%(" ".join(str(x) for x in token2)))
		count = 1
	if inputLine == "ADDRBEG":
		printAddress(parseAddress(file),count)
		count = count + 1
		print(" ")
	if inputLine == "CUSTOMEREND":
		print("     Address Address Score")
		for x in range (0, count):
			print("     0       0       0")
file.close()
	
