import sys
import re

class AddressSyntaxException(Exception):
    def __init__(self, *args, **kwargs):
        super().__init__(self, *args, **kwargs)

class PrefixSyntax(Exception):
    def __init__(self, *args, **kwargs):
        super().__init__(self, *args, **kwargs)

addressD = {}
directions = { 
		"NORTH":["NORTH", "N.", "N"],
 		"SOUTHWEST":["SW", "S.W.","S WEST","SOUTH W","SOUTHWEST"],
		"SOUTH" :["S","S.","SOUTH"],
		"NORTHWEST" :["NW","N.W.","NORTH W","N WEST","NORTHWEST"],
		"EAST" : ["E", "E.", "EAST"],
		"WEST" : ["W", "W.", "WEST"]
		}
streetType = {
		"ROAD":["ROAD","RD","RD."],
		"LANE":["LANE","LN"],
		"STREET":["ST","ST.","STREET"],
		"SQUARE":["SQ", "SQ.", "SQUARE"],
		"BOULEVARD":["BLVD","BOULEVARD","BLVD."],
		"AVENUE":["AVENUE","AVE","AVE."]
		}
apt = {
	"APARTMENT":["APT.", "N.R.", "NR", "APT", "NR.", "APARTMENT"]
	}
def parseAddress(file):
	string = ""
	StNum = ""
	Direction = ""
	stName = ""
	addressD['APT'] = ""
	addressD['STNAME'] = ""
	addressD['STNUM'] = ""
	addressD['STTYPE'] = ""
	addressD['DIR'] = ""
	addressD['CITY'] = ""
	addressD['LINE'] = ""
	addressD['STATE'] = ""
	addressD['ZIP'] = ""
	while True:
                inputLine = file.readline()
                if inputLine == "":
                        break
                inputLine = inputLine.rstrip('\n')
                if inputLine.split()[0] == "LINE":
                        lineParse = inputLine.split()
                        addressD['STNUM'] = lineParse[1]
                        if string == "":
                                string = string + ' '.join(inputLine.split()[1:])
                        else:
                                string += " " + ' '.join(inputLine.split()[1:])
                        for words in lineParse:
                                if words in [x for v in apt.values() for x in v]:
                                        addressD['APT'] = lineParse[-1]
                                if words in [x for v in streetType.values() for x in v]:
                                        addressD['STTYPE'] = (getKeyFromValue(streetType, words))
                                if words in [x for v in directions.values() for x in v]:
                                        addressD['DIR'] = (getKeyFromValue(directions, words)) 
                                else:
                                	stName = stName + " " +words
                if inputLine.split()[0] == "CITY":
                        addressD['CITY'] = inputLine.split()[1:]
                if inputLine.split()[0] == "STATE":
                        addressD['STATE'] = inputLine.split()[1:]
                if inputLine.split()[0] == "ZIP":
                        addressD['ZIP'] = inputLine.split()[1:]
                if inputLine == "ADDREND":
                        break
	stName = stName.replace('LINE', '')
	#stName = re.sub("\d+", " ", stName)
	addressD['LINE'] = string
	addressD['STNAME'] = stName
	matchZIP = " ".join(str(x) for x in addressD['ZIP'])
	##if (addressD['CITY'] == ""):
		##raise AddressSyntaxException("Missing City")
	##if (addressD['ZIP'] == ""):
		##raise AddressSyntaxException("Missing Zip Code")
	match = re.match(r'^\d{5}(?:[-\s]\d{4})?$', matchZIP)
	##if match == None:
		##raise AddressSyntaxException("Invalid Zip")
	##if (addressD['STATE'] == ""):
	##	try:
			
	##	except(AddressSyntaxException, PrefixSyntax) as e:
	##		print("***", str(e.args[1], "***"))
	#print(addressD)
	return addressD

def getKeyFromValue(dct, value):
	for k in dct:
		if isinstance(dct[k], list):
			if value in dct[k]:
				return k
		else:
			if value == dct[k]:
				return k

def Count(addressD, count):
	i = 1	

def printAddress(addressD, addressNr):
        print("%-6s %s"%(addressNr, ("".join(str(x) for x in addressD['LINE']))))
        print("%s %s, %s %s"%(" ".rjust(6),(" ".join(str(x) for x in addressD['CITY'])),(" ".join(str(x) for x in addressD['STATE'])),(" ".join(str(x) for x in addressD['ZIP']))))
        if (addressD['STATE'] == ""):
                print("%s ***Missing State***"%(" ".rjust(36)))
        elif (addressD['ZIP'] == ""):
                print("%s ***Missing Zip***"%(" ".rjust(36)))
        elif (addressD['CITY'] == ""):
                print("%s ***Missing City***"%(" ".rjust(36)))
        matchZIP = " ".join(str(x) for x in addressD['ZIP'])
        match = re.match(r'^\d{5}(?:[-\s]\d{4})?$', matchZIP)
        if match == None:
                print("%s ***Invalid ZIP***"%(" ".rjust(36)))
        elif (addressD['LINE'] == ""):
                print("%s ***Missing Address***"%(" ".rjust(36)))
        elif not addressD['LINE'][0].isdigit():
                print("%s ***Invalid Address***"%(" ".rjust(36)))
        else:
                print("%s %s %s %s %s %s"%(" ".ljust(34),("".join(str(x) for x in addressD['STNUM']).ljust(5)),("".join(str(x) for x in addressD['DIR']).ljust(10)),("".join(str(x) for x in addressD['APT']).ljust(6)),("".join(str(x) for x in addressD['STTYPE']).ljust(9)),("".join(str(x) for x in addressD['STNAME']))))
