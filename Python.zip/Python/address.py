addressD = {}
def getAddress(file):
	string = ""
	while True:
		inputLine = file.readline()
		if inputLine == "":
			break
		inputLine = inputLine.rstrip('\n')
		if inputLine.split()[0] == "LINE":
			if string == "":
				string = string + ' '.join(inputLine.split()[1:])
			else:
				string += " " + ' '.join(inputLine.split()[1:]) 
		if inputLine.split()[0] == "CITY":
			addressD['CITY'] = inputLine.split()[1:]
		if inputLine.split()[0] == "STATE":
			addressD['STATE'] = inputLine.split()[1:]
		if inputLine.split()[0] == "ZIP":
			addressD['ZIP'] = inputLine.split()[1:]
		if inputLine == "ADDREND":
			break
	addressD['LINE'] = string
	return addressD

def printAddress(addressD, addressNr):
	print("%-6s %s"%(addressNr, ("".join(str(x) for x in addressD['LINE']))))
	print("%s %s, %s %s"%(" ".rjust(6),(" ".join(str(x) for x in addressD['CITY'])),(" ".join(str(x) for x in addressD['STATE'])),(" ".join(str(x) for x in addressD['ZIP']))))
