#Imports

import sys
import re
from address import getAddress, printAddress


addressD = {}

if len(sys.argv) < 2:
	print("filename needed as command argument")
	sys.exit(1)

file = open(sys.argv[1], "r")

while True:
	inputLine = file.readline()
	if inputLine == "":
		break
	inputLine = inputLine.rstrip('\n')
	token = inputLine.split()
	token2 = token[1:]
	if token[0] == "CUSTOMER":
		print(" ".join(str(x) for x in token2))
		count = 1
		# NEED TO FIX
		#while "values" in getAddress(file).values():
		while count < 4:
			printAddress(getAddress(file),count)
			#print(getAddress(file).get("test"))
			#if getAddress(file).get("test") == 'help':
			#	break
			#printAddress(getAddress(file),count)
			count = count + 1
			print(" ")
	
